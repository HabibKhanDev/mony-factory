"use client";

import { useEffect, useRef, useState } from "react";
import { SUGGESTIONS, type ChartAction } from "@/lib/ai/actions";
import { useMarket } from "./market-context";
import { Button, Chip } from "./ui";

interface Msg {
  role: "user" | "assistant";
  content: string;
}

export default function ChatPanel({ height = 420 }: { height?: number }) {
  const { symbol, timeframe, applyActions } = useMarket();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    fetch("/api/chat")
      .then((r) => r.json())
      .then((j: { ok: boolean; messages?: { role: string; content: string }[] }) => {
        if (j.ok && j.messages?.length) {
          setMessages(
            j.messages.map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: m.content })),
          );
        }
      })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  const send = async (text: string) => {
    const message = text.trim();
    if (!message || busy) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", content: message }]);
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, symbol, timeframe }),
      });
      const json = (await res.json()) as {
        ok: boolean;
        reply?: string;
        actions?: ChartAction[];
        error?: string;
      };
      if (json.ok && json.reply) {
        setMessages((m) => [...m, { role: "assistant", content: json.reply as string }]);
        if (json.actions?.length) applyActions(json.actions);
      } else {
        setMessages((m) => [
          ...m,
          { role: "assistant", content: json.error ?? "Request failed." },
        ]);
      }
    } catch (err) {
      setMessages((m) => [
        ...m,
        { role: "assistant", content: err instanceof Error ? err.message : "Network error" },
      ]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex flex-col rounded-xl border border-slate-800/80 bg-[#0d1220]">
      <div className="flex items-center justify-between border-b border-slate-800/80 px-3 py-2">
        <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          AI Trading Chat · <span className="text-emerald-400">{symbol}</span> {timeframe}
        </div>
        <button
          type="button"
          onClick={async () => {
            await fetch("/api/chat", { method: "DELETE" });
            setMessages([]);
          }}
          className="text-[10px] text-slate-500 hover:text-slate-300"
        >
          clear
        </button>
      </div>

      <div ref={scrollRef} style={{ height }} className="flex-1 space-y-3 overflow-y-auto p-3">
        {messages.length === 0 && (
          <p className="text-xs text-slate-500">
            Connected to live Binance data, the scanner, the strategy engine and your signal history.
            Ask for an analysis or a chart drawing — every number comes from real calculations.
          </p>
        )}
        {messages.map((m, i) => (
          <div
            key={i}
            className={`whitespace-pre-wrap rounded-lg px-3 py-2 text-xs leading-relaxed ${
              m.role === "user"
                ? "ml-8 bg-emerald-500/10 text-emerald-100"
                : "mr-2 bg-slate-800/50 text-slate-200"
            }`}
          >
            {renderMarkdownish(m.content)}
          </div>
        ))}
        {busy && (
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="h-3 w-3 animate-spin rounded-full border-2 border-slate-600 border-t-emerald-400" />
            Running real calculations on Binance data…
          </div>
        )}
      </div>

      <div className="flex gap-1 overflow-x-auto border-t border-slate-800/80 px-2 py-2">
        {SUGGESTIONS.map((s) => (
          <Chip key={s} onClick={() => send(s)}>
            {s}
          </Chip>
        ))}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
        className="flex gap-2 border-t border-slate-800/80 p-2"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={`Ask about ${symbol}…`}
          className="flex-1 rounded-lg border border-slate-700 bg-[#0b101c] px-3 py-2 text-xs text-slate-200 outline-none focus:border-emerald-500/60"
        />
        <Button type="submit" disabled={busy}>
          Send
        </Button>
      </form>
    </div>
  );
}

function renderMarkdownish(text: string) {
  return text.split("\n").map((line, i) => {
    const bold = line.match(/^\*\*(.+)\*\*$/);
    if (bold) {
      return (
        <div key={i} className="mt-2 text-[11px] font-semibold uppercase tracking-wide text-emerald-300">
          {bold[1]}
        </div>
      );
    }
    return (
      <div key={i} className={line.startsWith("•") ? "pl-1" : ""}>
        {line.replace(/\*\*/g, "")}
      </div>
    );
  });
}

"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { ChartAction } from "@/lib/ai/actions";

export interface Drawings {
  support: { price: number; touches: number }[];
  resistance: { price: number; touches: number }[];
  trendlines: { kind: string; p1: { time: number; price: number }; p2: { time: number; price: number } }[];
  trade: { entry: number; stopLoss: number; tp1?: number; tp2?: number; tp3?: number } | null;
  showSwings: boolean;
}

const EMPTY: Drawings = {
  support: [],
  resistance: [],
  trendlines: [],
  trade: null,
  showSwings: false,
};

interface MarketCtx {
  symbol: string;
  timeframe: string;
  setSymbol: (s: string) => void;
  setTimeframe: (t: string) => void;
  drawings: Drawings;
  applyActions: (actions: ChartAction[]) => void;
  clearDrawings: () => void;
  toggleSwings: () => void;
}

const Ctx = createContext<MarketCtx | null>(null);

export function MarketProvider({ children }: { children: ReactNode }) {
  const [symbol, setSymbolState] = useState("BTCUSDT");
  const [timeframe, setTimeframeState] = useState("1h");
  const [drawings, setDrawings] = useState<Drawings>(EMPTY);

  useEffect(() => {
    try {
      const s = sessionStorage.getItem("gs.symbol");
      const t = sessionStorage.getItem("gs.tf");
      const d = sessionStorage.getItem("gs.drawings");
      if (s) setSymbolState(s);
      if (t) setTimeframeState(t);
      if (d) setDrawings({ ...EMPTY, ...(JSON.parse(d) as Drawings) });
    } catch {
      /* ignore */
    }
  }, []);

  const setSymbol = useCallback((s: string) => {
    setSymbolState(s.toUpperCase());
    try {
      sessionStorage.setItem("gs.symbol", s.toUpperCase());
    } catch {
      /* ignore */
    }
  }, []);

  const setTimeframe = useCallback((t: string) => {
    setTimeframeState(t);
    try {
      sessionStorage.setItem("gs.tf", t);
    } catch {
      /* ignore */
    }
  }, []);

  const persist = useCallback((d: Drawings) => {
    setDrawings(d);
    try {
      sessionStorage.setItem("gs.drawings", JSON.stringify(d));
    } catch {
      /* ignore */
    }
  }, []);

  const applyActions = useCallback(
    (actions: ChartAction[]) => {
      let next: Drawings = { ...drawings };
      for (const a of actions) {
        switch (a.type) {
          case "setSymbol":
            setSymbol(a.symbol);
            setTimeframe(a.timeframe);
            break;
          case "levels":
            next = { ...next, support: a.support, resistance: a.resistance };
            break;
          case "trendline":
            next = {
              ...next,
              trendlines: [
                ...next.trendlines.filter((t) => t.kind !== a.kind),
                { kind: a.kind, p1: a.p1, p2: a.p2 },
              ],
            };
            break;
          case "trade":
            next = {
              ...next,
              trade: { entry: a.entry, stopLoss: a.stopLoss, tp1: a.tp1, tp2: a.tp2, tp3: a.tp3 },
            };
            break;
          case "swings":
            next = { ...next, showSwings: true };
            break;
          case "clear":
            next = { ...EMPTY };
            break;
        }
      }
      persist(next);
    },
    [drawings, persist, setSymbol, setTimeframe],
  );

  const clearDrawings = useCallback(() => persist({ ...EMPTY }), [persist]);
  const toggleSwings = useCallback(
    () => persist({ ...drawings, showSwings: !drawings.showSwings }),
    [drawings, persist],
  );

  const value = useMemo(
    () => ({
      symbol,
      timeframe,
      setSymbol,
      setTimeframe,
      drawings,
      applyActions,
      clearDrawings,
      toggleSwings,
    }),
    [symbol, timeframe, setSymbol, setTimeframe, drawings, applyActions, clearDrawings, toggleSwings],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useMarket(): MarketCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useMarket must be used inside MarketProvider");
  return ctx;
}

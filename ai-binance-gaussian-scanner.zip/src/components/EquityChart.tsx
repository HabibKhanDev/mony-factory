"use client";

export default function EquityChart({
  points,
  height = 160,
  label = "Equity (start = 100)",
}: {
  points: { time: number; equity: number }[];
  height?: number;
  label?: string;
}) {
  if (points.length < 2) {
    return (
      <div className="flex h-24 items-center justify-center text-xs text-slate-500">
        Not enough closed trades to plot an equity curve yet.
      </div>
    );
  }
  const w = 600;
  const h = height;
  const pad = 8;
  const values = points.map((p) => p.equity);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const x = (i: number) => pad + (i / (points.length - 1)) * (w - pad * 2);
  const y = (v: number) => pad + (1 - (v - min) / range) * (h - pad * 2);
  const d = points.map((p, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(2)},${y(p.equity).toFixed(2)}`).join(" ");
  const area = `${d} L${x(points.length - 1).toFixed(2)},${h - pad} L${x(0).toFixed(2)},${h - pad} Z`;
  const positive = values[values.length - 1] >= values[0];
  const color = positive ? "#10b981" : "#ef4444";

  return (
    <div>
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full" style={{ height }} preserveAspectRatio="none">
        <path d={area} fill={color} opacity={0.12} />
        <path d={d} fill="none" stroke={color} strokeWidth={2} />
      </svg>
      <div className="flex justify-between text-[10px] text-slate-500">
        <span>{label}</span>
        <span>
          min {min.toFixed(2)} · max {max.toFixed(2)} · last {values[values.length - 1].toFixed(2)}
        </span>
      </div>
    </div>
  );
}

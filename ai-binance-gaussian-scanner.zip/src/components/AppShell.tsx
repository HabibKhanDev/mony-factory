"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";

const NAV = [
  { href: "/", label: "Dashboard", icon: "◎" },
  { href: "/scanner", label: "Scanner", icon: "▦" },
  { href: "/chart", label: "Chart", icon: "📈" },
  { href: "/chat", label: "AI Chat", icon: "✦" },
  { href: "/history", label: "History", icon: "🕘" },
];

const MORE = [
  { href: "/backtest", label: "Backtest", icon: "⏮" },
  { href: "/paper", label: "Paper", icon: "🧾" },
  { href: "/settings", label: "Settings", icon: "⚙" },
];

export default function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const isActive = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <div className="min-h-screen bg-[#080b12] text-slate-200">
      {/* Desktop sidebar */}
      <aside className="fixed left-0 top-0 hidden h-full w-56 flex-col border-r border-slate-800/80 bg-[#0b0f18] p-4 lg:flex">
        <div className="mb-6">
          <div className="text-sm font-semibold tracking-widest text-emerald-400">TRADLEWARE</div>
          <div className="text-xs text-slate-500">Gaussian AI Scanner</div>
        </div>
        <nav className="flex flex-1 flex-col gap-1">
          {[...NAV, ...MORE].map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition ${
                isActive(n.href)
                  ? "bg-emerald-500/10 text-emerald-300"
                  : "text-slate-400 hover:bg-slate-800/60 hover:text-slate-200"
              }`}
            >
              <span className="w-4 text-center">{n.icon}</span>
              {n.label}
            </Link>
          ))}
        </nav>
        <p className="mt-4 text-[10px] leading-relaxed text-slate-600">
          Real Binance data · analysis only. No real-money orders are ever placed.
        </p>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-slate-800/80 bg-[#0b0f18]/95 px-4 py-3 backdrop-blur lg:hidden">
        <div>
          <div className="text-xs font-semibold tracking-widest text-emerald-400">TRADLEWARE</div>
          <div className="text-[10px] text-slate-500">Gaussian AI Scanner</div>
        </div>
        <div className="flex gap-1">
          {MORE.map((m) => (
            <Link
              key={m.href}
              href={m.href}
              className={`rounded-md px-2 py-1 text-[11px] ${
                isActive(m.href) ? "bg-emerald-500/15 text-emerald-300" : "bg-slate-800/60 text-slate-400"
              }`}
            >
              {m.label}
            </Link>
          ))}
        </div>
      </header>

      <main className="mx-auto w-full max-w-[1400px] px-3 pb-24 pt-3 lg:pl-60 lg:pr-4 lg:pb-8">
        {children}
      </main>

      {/* Android-style bottom navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 grid grid-cols-5 border-t border-slate-800/80 bg-[#0b0f18]/98 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden">
        {NAV.map((n) => (
          <Link
            key={n.href}
            href={n.href}
            className={`flex flex-col items-center gap-0.5 py-2 text-[10px] ${
              isActive(n.href) ? "text-emerald-400" : "text-slate-500"
            }`}
          >
            <span className="text-base leading-none">{n.icon}</span>
            {n.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}

"use client";

import { useEffect, useRef, useState } from "react";
import type {
  IChartApi,
  IPriceLine,
  ISeriesApi,
  ISeriesMarkersPluginApi,
  Time,
  UTCTimestamp,
} from "lightweight-charts";
import type { Drawings } from "./market-context";
import type { CandlesResponse } from "@/lib/types";

interface Props {
  data: CandlesResponse | null;
  drawings: Drawings;
  showChannel?: boolean;
  showSma?: boolean;
  height?: number;
}

interface Refs {
  chart: IChartApi;
  candles: ISeriesApi<"Candlestick">;
  volume: ISeriesApi<"Histogram">;
  filt: ISeriesApi<"Line">;
  hband: ISeriesApi<"Line">;
  lband: ISeriesApi<"Line">;
  sma: ISeriesApi<"Line">;
  markers: ISeriesMarkersPluginApi<Time>;
  priceLines: IPriceLine[];
  extraSeries: ISeriesApi<"Line">[];
}

export default function ChartPanel({
  data,
  drawings,
  showChannel = true,
  showSma = true,
  height = 420,
}: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const refs = useRef<Refs | null>(null);
  const [ready, setReady] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);

  // ---- create chart once ------------------------------------------------
  useEffect(() => {
    let disposed = false;
    let cleanupResize: (() => void) | null = null;

    (async () => {
      const lwc = await import("lightweight-charts");
      if (disposed || !containerRef.current) return;

      const chart = lwc.createChart(containerRef.current, {
        layout: {
          background: { color: "#0b0f18" },
          textColor: "#94a3b8",
          fontSize: 11,
          attributionLogo: false,
        },
        grid: {
          vertLines: { color: "rgba(148,163,184,0.06)" },
          horzLines: { color: "rgba(148,163,184,0.06)" },
        },
        rightPriceScale: { borderColor: "rgba(148,163,184,0.2)" },
        timeScale: {
          borderColor: "rgba(148,163,184,0.2)",
          timeVisible: true,
          secondsVisible: false,
        },
        crosshair: { mode: lwc.CrosshairMode.Normal },
        handleScroll: true,
        handleScale: true,
        autoSize: true,
      });

      const candles = chart.addSeries(lwc.CandlestickSeries, {
        upColor: "#10b981",
        downColor: "#ef4444",
        borderVisible: false,
        wickUpColor: "#10b981",
        wickDownColor: "#ef4444",
      });
      candles.priceScale().applyOptions({ scaleMargins: { top: 0.08, bottom: 0.28 } });

      const volume = chart.addSeries(lwc.HistogramSeries, {
        priceFormat: { type: "volume" },
        priceScaleId: "vol",
        color: "rgba(56,189,248,0.4)",
      });
      chart.priceScale("vol").applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } });

      const mkLine = (color: string, width: 1 | 2 | 3, dashed = false) =>
        chart.addSeries(lwc.LineSeries, {
          color,
          lineWidth: width,
          lineStyle: dashed ? lwc.LineStyle.Dashed : lwc.LineStyle.Solid,
          priceLineVisible: false,
          lastValueVisible: false,
          crosshairMarkerVisible: false,
        });

      const filt = mkLine("#f59e0b", 2);
      const hband = mkLine("#22d3ee", 1);
      const lband = mkLine("#22d3ee", 1);
      const sma = mkLine("#a78bfa", 2, true);
      const markers = lwc.createSeriesMarkers(candles, []);

      refs.current = {
        chart,
        candles,
        volume,
        filt,
        hband,
        lband,
        sma,
        markers,
        priceLines: [],
        extraSeries: [],
      };
      setReady(true);

      const onResize = () => chart.applyOptions({});
      window.addEventListener("resize", onResize);
      cleanupResize = () => window.removeEventListener("resize", onResize);
    })();

    return () => {
      disposed = true;
      cleanupResize?.();
      refs.current?.chart.remove();
      refs.current = null;
      setReady(false);
    };
  }, []);

  // ---- push real data ---------------------------------------------------
  useEffect(() => {
    const r = refs.current;
    if (!ready || !r || !data?.ok) return;

    const t = (v: number) => v as UTCTimestamp;
    r.candles.setData(
      data.candles.map((c) => ({
        time: t(c.time),
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      })),
    );
    r.volume.setData(
      data.candles.map((c) => ({
        time: t(c.time),
        value: c.volume,
        color: c.close >= c.open ? "rgba(16,185,129,0.35)" : "rgba(239,68,68,0.35)",
      })),
    );
    r.filt.setData(showChannel ? data.series.filt.map((p) => ({ time: t(p.time), value: p.value })) : []);
    r.hband.setData(showChannel ? data.series.hband.map((p) => ({ time: t(p.time), value: p.value })) : []);
    r.lband.setData(showChannel ? data.series.lband.map((p) => ({ time: t(p.time), value: p.value })) : []);
    r.sma.setData(showSma ? data.series.sma.map((p) => ({ time: t(p.time), value: p.value })) : []);

    r.markers.setMarkers(
      data.markers.map((m) => ({
        time: t(m.time),
        position: m.type === "BUY" ? ("belowBar" as const) : ("aboveBar" as const),
        color: m.type === "BUY" ? "#10b981" : "#ef4444",
        shape: m.type === "BUY" ? ("arrowUp" as const) : ("arrowDown" as const),
        text: m.type,
      })),
    );
  }, [data, ready, showChannel, showSma]);

  // ---- AI drawings (support/resistance, trendlines, entry/SL/TP) --------
  useEffect(() => {
    const r = refs.current;
    if (!ready || !r || !data?.ok) return;
    let cancelled = false;

    (async () => {
      const lwc = await import("lightweight-charts");
      if (cancelled || !refs.current) return;
      const rr = refs.current;

      for (const pl of rr.priceLines) rr.candles.removePriceLine(pl);
      rr.priceLines = [];
      for (const s of rr.extraSeries) rr.chart.removeSeries(s);
      rr.extraSeries = [];

      const addLine = (price: number, color: string, title: string, dashed = true) => {
        if (!Number.isFinite(price)) return;
        rr.priceLines.push(
          rr.candles.createPriceLine({
            price,
            color,
            lineWidth: 1,
            lineStyle: dashed ? lwc.LineStyle.Dashed : lwc.LineStyle.Solid,
            axisLabelVisible: true,
            title,
          }),
        );
      };

      drawings.support.forEach((s, i) => addLine(s.price, "#22c55e", `S${i + 1}`));
      drawings.resistance.forEach((s, i) => addLine(s.price, "#f43f5e", `R${i + 1}`));

      if (drawings.trade) {
        addLine(drawings.trade.entry, "#38bdf8", "ENTRY", false);
        addLine(drawings.trade.stopLoss, "#ef4444", "STOP LOSS", false);
        if (drawings.trade.tp1) addLine(drawings.trade.tp1, "#10b981", "AI TP1");
        if (drawings.trade.tp2) addLine(drawings.trade.tp2, "#14b8a6", "AI TP2");
        if (drawings.trade.tp3) addLine(drawings.trade.tp3, "#34d399", "AI TP3");
      }

      for (const tl of drawings.trendlines) {
        const series = rr.chart.addSeries(lwc.LineSeries, {
          color: tl.kind === "UPTREND" ? "#22c55e" : "#f97316",
          lineWidth: 2,
          lineStyle: lwc.LineStyle.Solid,
          priceLineVisible: false,
          lastValueVisible: false,
          crosshairMarkerVisible: false,
        });
        const pts = [tl.p1, tl.p2]
          .sort((a, b) => a.time - b.time)
          .map((p) => ({ time: p.time as UTCTimestamp, value: p.price }));
        series.setData(pts);
        rr.extraSeries.push(series);
      }

      if (drawings.showSwings && data.swings.length) {
        const highs = rr.chart.addSeries(lwc.LineSeries, {
          color: "rgba(248,113,113,0.8)",
          lineWidth: 1,
          lineStyle: lwc.LineStyle.Dotted,
          priceLineVisible: false,
          lastValueVisible: false,
        });
        highs.setData(
          data.swings
            .filter((s) => s.kind === "HIGH")
            .map((s) => ({ time: s.time as UTCTimestamp, value: s.price })),
        );
        const lows = rr.chart.addSeries(lwc.LineSeries, {
          color: "rgba(74,222,128,0.8)",
          lineWidth: 1,
          lineStyle: lwc.LineStyle.Dotted,
          priceLineVisible: false,
          lastValueVisible: false,
        });
        lows.setData(
          data.swings
            .filter((s) => s.kind === "LOW")
            .map((s) => ({ time: s.time as UTCTimestamp, value: s.price })),
        );
        rr.extraSeries.push(highs, lows);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [drawings, data, ready]);

  const toggleFullscreen = async () => {
    const el = containerRef.current?.parentElement;
    if (!el) return;
    if (!document.fullscreenElement) {
      await el.requestFullscreen().catch(() => undefined);
      setFullscreen(true);
    } else {
      await document.exitFullscreen().catch(() => undefined);
      setFullscreen(false);
    }
  };

  return (
    <div className="relative overflow-hidden rounded-xl border border-slate-800/80 bg-[#0b0f18]">
      <div ref={containerRef} style={{ height: fullscreen ? "100vh" : height }} className="w-full" />
      <button
        type="button"
        onClick={toggleFullscreen}
        className="absolute right-2 top-2 z-10 rounded-md border border-slate-700 bg-slate-900/80 px-2 py-1 text-[10px] text-slate-300"
      >
        {fullscreen ? "Exit" : "Fullscreen"}
      </button>
      <div className="pointer-events-none absolute left-2 top-2 z-10 flex flex-wrap gap-2 text-[10px]">
        <LegendDot color="#f59e0b" label="Gaussian filter" />
        <LegendDot color="#22d3ee" label="Bands" />
        <LegendDot color="#a78bfa" label={`SMA${data?.settings?.smaLength ?? 200}`} />
      </div>
      {!data?.ok && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0b0f18]/80 text-xs text-slate-400">
          {data?.error ?? "Loading real Binance candles…"}
        </div>
      )}
    </div>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1 rounded bg-slate-900/70 px-1.5 py-0.5 text-slate-400">
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
      {label}
    </span>
  );
}

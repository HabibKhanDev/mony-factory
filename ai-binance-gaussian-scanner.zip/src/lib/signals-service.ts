import { and, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { paperAccount, signals } from "@/db/schema";
import { getKlines } from "./binance";
import type { ScanRow } from "./scanner";

export type SignalRow = typeof signals.$inferSelect;

/** Persist BUY/EXIT signals produced by the real strategy (idempotent per candle). */
export async function recordSignals(
  rows: ScanRow[],
  timeframe: string,
  opts: { paper?: boolean; balance?: number; positionPct?: number } = {},
): Promise<number> {
  const actionable = rows.filter((r) => r.signal === "BUY" || r.signal === "EXIT");
  if (!actionable.length) return 0;

  const existing = await db
    .select({
      symbol: signals.symbol,
      candleTime: signals.candleTime,
      signal: signals.signal,
      timeframe: signals.timeframe,
    })
    .from(signals)
    .where(
      and(
        eq(signals.timeframe, timeframe),
        inArray(
          signals.symbol,
          actionable.map((r) => r.symbol),
        ),
      ),
    );
  const seen = new Set(
    existing.map((e) => `${e.symbol}|${e.signal}|${new Date(e.candleTime).getTime()}`),
  );

  const toInsert = actionable
    .filter((r) => !seen.has(`${r.symbol}|${r.signal}|${r.candleTime * 1000}`))
    .map((r) => {
      const notional = opts.paper && opts.balance
        ? (opts.balance * (opts.positionPct ?? 10)) / 100
        : null;
      return {
        symbol: r.symbol,
        timeframe,
        signal: r.signal,
        status: r.signal === "BUY" ? "ACTIVE" : "EXIT",
        entry: r.price,
        stopLoss: r.stopLoss,
        tp1: r.tp1,
        tp2: r.tp2,
        tp3: r.tp3,
        aiScore: Math.round(r.score),
        candleTime: new Date(r.candleTime * 1000),
        exitTime: r.signal === "EXIT" ? new Date() : null,
        exitPrice: r.signal === "EXIT" ? r.price : null,
        exitReason: r.signal === "EXIT" ? "CHANNEL_EXIT" : null,
        pnlPct: null,
        paper: Boolean(opts.paper),
        qty: notional ? notional / r.price : null,
        notional,
        meta: {
          rsi: r.rsi,
          stochK: r.stochK,
          hband: r.hband,
          lband: r.lband,
          sma200: r.sma200,
          regime: r.regime,
          trend: r.trend,
          volumeRatio: r.volumeRatio,
        },
      };
    });

  if (!toInsert.length) return 0;
  await db.insert(signals).values(toInsert);
  return toInsert.length;
}

const MAX_BARS_ALIVE = 200;

/** Re-evaluate every ACTIVE signal against real Binance candles since the signal time. */
export async function updateActiveSignals(limit = 60): Promise<number> {
  const active = await db
    .select()
    .from(signals)
    .where(eq(signals.status, "ACTIVE"))
    .orderBy(desc(signals.signalTime))
    .limit(limit);

  let updated = 0;
  for (const s of active) {
    try {
      const candles = await getKlines(s.symbol, s.timeframe, 300);
      const after = candles.filter(
        (c) => c.time * 1000 > new Date(s.candleTime).getTime() && c.closed,
      );
      if (!after.length) continue;

      let status = s.status;
      let exitPrice: number | null = null;
      let exitTime: Date | null = null;
      let reason: string | null = null;

      for (const c of after) {
        if (s.stopLoss && c.low <= s.stopLoss) {
          status = "STOP_LOSS";
          exitPrice = s.stopLoss;
          exitTime = new Date(c.time * 1000);
          reason = "STOP_LOSS";
          break;
        }
        if (s.tp3 && c.high >= s.tp3) {
          status = "TP3_HIT";
          exitPrice = s.tp3;
          exitTime = new Date(c.time * 1000);
          reason = "AI_TP3";
          break;
        }
        if (s.tp2 && c.high >= s.tp2) {
          status = "TP2_HIT";
          exitPrice = s.tp2;
          exitTime = new Date(c.time * 1000);
          reason = "AI_TP2";
          continue;
        }
        if (s.tp1 && c.high >= s.tp1 && status === "ACTIVE") {
          status = "TP1_HIT";
          exitPrice = s.tp1;
          exitTime = new Date(c.time * 1000);
          reason = "AI_TP1";
        }
      }

      if (status === "ACTIVE" && after.length > MAX_BARS_ALIVE) {
        status = "EXPIRED";
        const last = after[after.length - 1];
        exitPrice = last.close;
        exitTime = new Date(last.time * 1000);
        reason = "EXPIRED";
      }

      if (status !== s.status) {
        const pnl = exitPrice ? ((exitPrice - s.entry) / s.entry) * 100 : null;
        await db
          .update(signals)
          .set({
            status,
            exitPrice,
            exitTime,
            exitReason: reason,
            pnlPct: pnl,
          })
          .where(eq(signals.id, s.id));
        updated++;

        if (s.paper && pnl !== null && s.notional) {
          const acc = await ensurePaperAccount();
          const newBalance = acc.balance + (s.notional * pnl) / 100;
          await db
            .update(paperAccount)
            .set({ balance: newBalance, updatedAt: new Date() })
            .where(eq(paperAccount.id, acc.id));
        }
      }
    } catch {
      // Binance unavailable for this symbol: leave the signal untouched.
    }
  }
  return updated;
}

export async function ensurePaperAccount() {
  const rows = await db.select().from(paperAccount).where(eq(paperAccount.name, "default")).limit(1);
  if (rows.length) return rows[0];
  const inserted = await db
    .insert(paperAccount)
    .values({ name: "default" })
    .returning();
  return inserted[0];
}

export interface PerformanceStats {
  totalSignals: number;
  buySignals: number;
  exitSignals: number;
  active: number;
  wins: number;
  losses: number;
  winRate: number;
  totalPnlPct: number;
  avgPnlPct: number;
  bestCoin: string | null;
  bestTimeframe: string | null;
  maxDrawdownPct: number;
  equity: { time: number; equity: number }[];
  byStatus: Record<string, number>;
}

export async function performance(): Promise<PerformanceStats> {
  const all = await db.select().from(signals).orderBy(signals.signalTime);
  const closed = all.filter((s) => s.pnlPct !== null && s.signal === "BUY");
  const wins = closed.filter((s) => (s.pnlPct ?? 0) > 0);
  const losses = closed.filter((s) => (s.pnlPct ?? 0) <= 0);

  const byCoin = new Map<string, number>();
  const byTf = new Map<string, number>();
  for (const s of closed) {
    byCoin.set(s.symbol, (byCoin.get(s.symbol) ?? 0) + (s.pnlPct ?? 0));
    byTf.set(s.timeframe, (byTf.get(s.timeframe) ?? 0) + (s.pnlPct ?? 0));
  }
  const bestCoin = [...byCoin.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;
  const bestTimeframe = [...byTf.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;

  let equity = 100;
  let peak = 100;
  let maxDd = 0;
  const curve: { time: number; equity: number }[] = [{ time: 0, equity: 100 }];
  for (const s of closed) {
    equity *= 1 + (s.pnlPct ?? 0) / 100;
    peak = Math.max(peak, equity);
    maxDd = Math.max(maxDd, ((peak - equity) / peak) * 100);
    curve.push({
      time: new Date(s.exitTime ?? s.signalTime).getTime(),
      equity,
    });
  }

  const byStatus: Record<string, number> = {};
  for (const s of all) byStatus[s.status] = (byStatus[s.status] ?? 0) + 1;

  const total = closed.reduce((a, s) => a + (s.pnlPct ?? 0), 0);
  return {
    totalSignals: all.length,
    buySignals: all.filter((s) => s.signal === "BUY").length,
    exitSignals: all.filter((s) => s.signal === "EXIT").length,
    active: all.filter((s) => s.status === "ACTIVE").length,
    wins: wins.length,
    losses: losses.length,
    winRate: closed.length ? (wins.length / closed.length) * 100 : 0,
    totalPnlPct: total,
    avgPnlPct: closed.length ? total / closed.length : 0,
    bestCoin,
    bestTimeframe,
    maxDrawdownPct: maxDd,
    equity: curve,
    byStatus,
  };
}

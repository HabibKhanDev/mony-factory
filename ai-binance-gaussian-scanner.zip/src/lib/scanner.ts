import { getKlines, getUsdtTickers, mapLimit, type Ticker } from "./binance";
import { aiScore, aiTakeProfit } from "./analysis/structure";
import { runStrategy } from "./strategy/engine";
import type { StrategySettings } from "./strategy/settings";

export interface ScanRow {
  symbol: string;
  price: number;
  change24h: number;
  quoteVolume: number;
  trend: "UP" | "DOWN";
  filt: number;
  hband: number;
  lband: number;
  stochK: number;
  stochD: number;
  rsi: number;
  sma200: number;
  regime: "BULL" | "BEAR";
  bullishCandle: boolean;
  breakout: boolean;
  signal: "BUY" | "EXIT" | "WAIT";
  score: number;
  inPosition: boolean;
  distanceToUpperPct: number;
  distanceToSmaPct: number;
  volumeRatio: number;
  trendSlopePct: number;
  atr: number;
  entry: number;
  stopLoss: number;
  tp1: number | null;
  tp2: number | null;
  tp3: number | null;
  candleTime: number;
  winRate: number;
  trades: number;
}

export interface ScanResult {
  timeframe: string;
  scanned: number;
  failed: number;
  rows: ScanRow[];
  generatedAt: number;
}

const SCAN_CANDLES = 400;

export async function scanMarket(
  timeframe: string,
  settings: StrategySettings,
  opts: { limit?: number; symbols?: string[]; concurrency?: number } = {},
): Promise<ScanResult> {
  const tickers = await getUsdtTickers();
  let universe: Ticker[];
  if (opts.symbols?.length) {
    const wanted = new Set(opts.symbols.map((s) => s.toUpperCase()));
    universe = tickers.filter((t) => wanted.has(t.symbol));
  } else {
    universe = tickers.slice(0, Math.min(opts.limit ?? 40, 150));
  }

  let failed = 0;
  const rows = await mapLimit(universe, opts.concurrency ?? 10, async (t) => {
    try {
      const candles = await getKlines(t.symbol, timeframe, SCAN_CANDLES);
      if (candles.filter((c) => c.closed).length < settings.smaLength + 10) return null;
      const run = runStrategy(candles, settings);
      const s = run.state;
      if (!Number.isFinite(s.close) || !Number.isFinite(s.filt)) return null;
      const { score } = aiScore(run);
      const entry = s.close;
      const stop = Number.isFinite(s.lband) ? s.lband : s.close * 0.97;
      const targets = settings.useAiTp ? aiTakeProfit(entry, stop, s.atr, []) : null;

      const row: ScanRow = {
        symbol: t.symbol,
        price: t.lastPrice,
        change24h: t.priceChangePercent,
        quoteVolume: t.quoteVolume,
        trend: s.channelGreen ? "UP" : "DOWN",
        filt: s.filt,
        hband: s.hband,
        lband: s.lband,
        stochK: s.k,
        stochD: s.d,
        rsi: s.rsi,
        sma200: s.sma200,
        regime: s.close > s.sma200 ? "BULL" : "BEAR",
        bullishCandle: s.close > s.open,
        breakout: s.breakout,
        signal: s.signal,
        score,
        inPosition: s.inPosition,
        distanceToUpperPct: s.distanceToUpperPct,
        distanceToSmaPct: s.distanceToSmaPct,
        volumeRatio: s.volumeRatio,
        trendSlopePct: s.trendSlopePct,
        atr: s.atr,
        entry,
        stopLoss: stop,
        tp1: targets?.tp1 ?? null,
        tp2: targets?.tp2 ?? null,
        tp3: targets?.tp3 ?? null,
        candleTime: s.time,
        winRate: run.backtest.stats.winRate,
        trades: run.backtest.stats.totalTrades,
      };
      return row;
    } catch {
      failed++;
      return null;
    }
  });

  const clean = rows.filter((r): r is ScanRow => r !== null);
  clean.sort((a, b) => b.score - a.score);

  return {
    timeframe,
    scanned: clean.length,
    failed,
    rows: clean,
    generatedAt: Date.now(),
  };
}

export type ScanFilter =
  | "ALL"
  | "BUY"
  | "EXIT"
  | "WAIT"
  | "HIGH_CONFIDENCE"
  | "BULLISH"
  | "BEARISH"
  | "BREAKOUT"
  | "HIGH_VOLUME";

export function applyFilter(rows: ScanRow[], filter: ScanFilter): ScanRow[] {
  switch (filter) {
    case "BUY":
      return rows.filter((r) => r.signal === "BUY");
    case "EXIT":
      return rows.filter((r) => r.signal === "EXIT");
    case "WAIT":
      return rows.filter((r) => r.signal === "WAIT");
    case "HIGH_CONFIDENCE":
      return rows.filter((r) => r.score >= 70);
    case "BULLISH":
      return rows.filter((r) => r.trend === "UP" && r.regime === "BULL");
    case "BEARISH":
      return rows.filter((r) => r.trend === "DOWN" || r.regime === "BEAR");
    case "BREAKOUT":
      return rows.filter((r) => r.breakout);
    case "HIGH_VOLUME":
      return rows.filter((r) => Number.isFinite(r.volumeRatio) && r.volumeRatio >= 1.5);
    default:
      return rows;
  }
}

export type ScanSort = "SCORE" | "VOLUME" | "CHANGE" | "TREND";

export function applySort(rows: ScanRow[], sort: ScanSort): ScanRow[] {
  const copy = [...rows];
  switch (sort) {
    case "VOLUME":
      return copy.sort((a, b) => b.quoteVolume - a.quoteVolume);
    case "CHANGE":
      return copy.sort((a, b) => b.change24h - a.change24h);
    case "TREND":
      return copy.sort(
        (a, b) => (b.trendSlopePct || 0) - (a.trendSlopePct || 0),
      );
    default:
      return copy.sort((a, b) => b.score - a.score);
  }
}

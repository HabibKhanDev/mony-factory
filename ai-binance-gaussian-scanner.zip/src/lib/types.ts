import type { StrategyState } from "./strategy/engine";
import type { AiTargets, Level, Swing, Trendline } from "./analysis/structure";
import type { StrategySettings } from "./strategy/settings";
import type { ScanRow } from "./scanner";

export interface LinePoint {
  time: number;
  value: number;
}

export interface ChartCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface ChartMarker {
  time: number;
  type: "BUY" | "EXIT";
  price: number;
  reason: string;
}

export interface CandlesResponse {
  ok: boolean;
  error?: string;
  symbol: string;
  timeframe: string;
  candles: ChartCandle[];
  series: {
    filt: LinePoint[];
    hband: LinePoint[];
    lband: LinePoint[];
    sma: LinePoint[];
    rsi: LinePoint[];
    k: LinePoint[];
    d: LinePoint[];
  };
  markers: ChartMarker[];
  state: StrategyState;
  score: number;
  scoreParts: { label: string; value: number; max: number; note: string }[];
  structure: string;
  support: Level[];
  resistance: Level[];
  swings: Swing[];
  trendline: Trendline | null;
  downTrendline: Trendline | null;
  targets: AiTargets | null;
  backtest: {
    totalTrades: number;
    wins: number;
    losses: number;
    winRate: number;
    netPnlPct: number;
    maxDrawdownPct: number;
    profitFactor: number;
    avgTradePct: number;
    largestWinPct: number;
    largestLossPct: number;
  };
  settings: StrategySettings;
}

export interface ScanResponse {
  ok: boolean;
  error?: string;
  timeframe: string;
  generatedAt: number;
  scanned: number;
  failed: number;
  counts: {
    buy: number;
    exit: number;
    wait: number;
    breakout: number;
    bull: number;
    highConfidence: number;
  };
  top: ScanRow[];
  rows: ScanRow[];
  settings: StrategySettings;
}

export type { ScanRow, StrategySettings, StrategyState, AiTargets, Level, Swing, Trendline };

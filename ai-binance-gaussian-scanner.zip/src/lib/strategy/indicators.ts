/**
 * Faithful TypeScript ports of the TradingView (Pine v6) built-in functions
 * that the Gaussian Channel + StochRSI strategy relies on.
 * Every function returns a bar-aligned array (index === bar index),
 * using NaN where Pine would return `na`.
 */

export const nan = Number.NaN;

export function sma(src: number[], length: number): number[] {
  const out = new Array<number>(src.length).fill(nan);
  if (length <= 0) return out;
  let sum = 0;
  let count = 0;
  for (let i = 0; i < src.length; i++) {
    const v = src[i];
    if (Number.isNaN(v)) {
      // Pine skips na leading values; restart accumulation window.
      sum = 0;
      count = 0;
      continue;
    }
    sum += v;
    count++;
    if (count > length) {
      const drop = src[i - length];
      sum -= drop;
      count--;
    }
    if (count === length) out[i] = sum / length;
  }
  return out;
}

/** Wilder's RMA (used by ta.rsi). */
export function rma(src: number[], length: number): number[] {
  const out = new Array<number>(src.length).fill(nan);
  let sum = 0;
  let count = 0;
  let prev = nan;
  for (let i = 0; i < src.length; i++) {
    const v = src[i];
    if (Number.isNaN(v)) continue;
    if (Number.isNaN(prev)) {
      sum += v;
      count++;
      if (count === length) {
        prev = sum / length;
        out[i] = prev;
      }
    } else {
      prev = (prev * (length - 1) + v) / length;
      out[i] = prev;
    }
  }
  return out;
}

/** ta.rsi(close, length) */
export function rsi(src: number[], length: number): number[] {
  const gains = new Array<number>(src.length).fill(nan);
  const losses = new Array<number>(src.length).fill(nan);
  for (let i = 1; i < src.length; i++) {
    const change = src[i] - src[i - 1];
    gains[i] = Math.max(change, 0);
    losses[i] = Math.max(-change, 0);
  }
  const avgGain = rma(gains, length);
  const avgLoss = rma(losses, length);
  const out = new Array<number>(src.length).fill(nan);
  for (let i = 0; i < src.length; i++) {
    const g = avgGain[i];
    const l = avgLoss[i];
    if (Number.isNaN(g) || Number.isNaN(l)) continue;
    if (l === 0) out[i] = 100;
    else if (g === 0) out[i] = 0;
    else out[i] = 100 - 100 / (1 + g / l);
  }
  return out;
}

export function highest(src: number[], length: number): number[] {
  const out = new Array<number>(src.length).fill(nan);
  for (let i = 0; i < src.length; i++) {
    if (i + 1 < length) continue;
    let mx = -Infinity;
    let ok = true;
    for (let j = i - length + 1; j <= i; j++) {
      const v = src[j];
      if (Number.isNaN(v)) {
        ok = false;
        break;
      }
      if (v > mx) mx = v;
    }
    if (ok) out[i] = mx;
  }
  return out;
}

export function lowest(src: number[], length: number): number[] {
  const out = new Array<number>(src.length).fill(nan);
  for (let i = 0; i < src.length; i++) {
    if (i + 1 < length) continue;
    let mn = Infinity;
    let ok = true;
    for (let j = i - length + 1; j <= i; j++) {
      const v = src[j];
      if (Number.isNaN(v)) {
        ok = false;
        break;
      }
      if (v < mn) mn = v;
    }
    if (ok) out[i] = mn;
  }
  return out;
}

/** ta.stoch(src, high, low, length) — here called with rsi for all three. */
export function stoch(
  src: number[],
  highSrc: number[],
  lowSrc: number[],
  length: number,
): number[] {
  const hh = highest(highSrc, length);
  const ll = lowest(lowSrc, length);
  const out = new Array<number>(src.length).fill(nan);
  for (let i = 0; i < src.length; i++) {
    if (Number.isNaN(hh[i]) || Number.isNaN(ll[i]) || Number.isNaN(src[i])) continue;
    const range = hh[i] - ll[i];
    out[i] = range === 0 ? 0 : (100 * (src[i] - ll[i])) / range;
  }
  return out;
}

/** ta.tr(true): true range where the first bar falls back to high - low. */
export function trueRange(
  high: number[],
  low: number[],
  close: number[],
): number[] {
  const out = new Array<number>(high.length).fill(nan);
  for (let i = 0; i < high.length; i++) {
    if (i === 0) {
      out[i] = high[i] - low[i];
      continue;
    }
    const pc = close[i - 1];
    out[i] = Math.max(
      high[i] - low[i],
      Math.abs(high[i] - pc),
      Math.abs(low[i] - pc),
    );
  }
  return out;
}

/** ta.atr(length) = rma(tr, length) */
export function atr(
  high: number[],
  low: number[],
  close: number[],
  length: number,
): number[] {
  return rma(trueRange(high, low, close), length);
}

export function lastValid(arr: number[]): number {
  for (let i = arr.length - 1; i >= 0; i--) {
    if (!Number.isNaN(arr[i])) return arr[i];
  }
  return nan;
}

/**
 * Direct port of the Pine v6 Gaussian Channel (Ehlers 9x filter) used by
 * "TRADLEWARE-Gaussian Channel ETH" (author: cs_lev).
 *
 * f_filt9x / f_pole are reproduced 1:1 including the binomial coefficient
 * tables and the nz() behaviour of the recursive feedback terms.
 */

const nz = (v: number | undefined): number =>
  v === undefined || Number.isNaN(v) ? 0 : v;

/** Pine's f_filt9x(_a, _s, _i) evaluated across the whole series. */
export function filt9x(alpha: number, src: number[], i: number): number[] {
  const x = 1 - alpha;

  const m2 =
    i === 9 ? 36 : i === 8 ? 28 : i === 7 ? 21 : i === 6 ? 15 : i === 5 ? 10 : i === 4 ? 6 : i === 3 ? 3 : i === 2 ? 1 : 0;
  const m3 =
    i === 9 ? 84 : i === 8 ? 56 : i === 7 ? 35 : i === 6 ? 20 : i === 5 ? 10 : i === 4 ? 4 : i === 3 ? 1 : 0;
  const m4 =
    i === 9 ? 126 : i === 8 ? 70 : i === 7 ? 35 : i === 6 ? 15 : i === 5 ? 5 : i === 4 ? 1 : 0;
  const m5 = i === 9 ? 126 : i === 8 ? 56 : i === 7 ? 21 : i === 6 ? 6 : i === 5 ? 1 : 0;
  const m6 = i === 9 ? 84 : i === 8 ? 28 : i === 7 ? 7 : i === 6 ? 1 : 0;
  const m7 = i === 9 ? 36 : i === 8 ? 8 : i === 7 ? 1 : 0;
  const m8 = i === 9 ? 9 : i === 8 ? 1 : 0;
  const m9 = i === 9 ? 1 : 0;

  const ai = Math.pow(alpha, i);
  const x2 = Math.pow(x, 2);
  const x3 = Math.pow(x, 3);
  const x4 = Math.pow(x, 4);
  const x5 = Math.pow(x, 5);
  const x6 = Math.pow(x, 6);
  const x7 = Math.pow(x, 7);
  const x8 = Math.pow(x, 8);
  const x9 = Math.pow(x, 9);

  const f = new Array<number>(src.length).fill(0);
  for (let b = 0; b < src.length; b++) {
    const s = nz(src[b]);
    let v = ai * s + i * x * nz(f[b - 1]);
    if (i >= 2) v -= m2 * x2 * nz(f[b - 2]);
    if (i >= 3) v += m3 * x3 * nz(f[b - 3]);
    if (i >= 4) v -= m4 * x4 * nz(f[b - 4]);
    if (i >= 5) v += m5 * x5 * nz(f[b - 5]);
    if (i >= 6) v -= m6 * x6 * nz(f[b - 6]);
    if (i >= 7) v += m7 * x7 * nz(f[b - 7]);
    if (i >= 8) v -= m8 * x8 * nz(f[b - 8]);
    if (i === 9) v += m9 * x9 * nz(f[b - 9]);
    f[b] = v;
  }
  return f;
}

/** Pine's f_pole(_a, _s, _i) -> [filtN, filt1] */
export function fPole(
  alpha: number,
  src: number[],
  poles: number,
): { fn: number[]; f1: number[] } {
  const f1 = filt9x(alpha, src, 1);
  const fn = poles === 1 ? f1 : filt9x(alpha, src, poles);
  return { fn, f1 };
}

export interface GaussianParams {
  poles: number;
  period: number;
  multiplier: number;
  reducedLag: boolean;
  fastResponse: boolean;
}

export interface GaussianResult {
  filt: number[];
  hband: number[];
  lband: number[];
  filttr: number[];
  alpha: number;
  beta: number;
  lag: number;
}

/**
 * Computes the Gaussian channel exactly like the Pine source:
 *  beta  = (1 - cos(4*asin(1)/per)) / (1.414^(2/N) - 1)
 *  alpha = -beta + sqrt(beta^2 + 2*beta)
 *  lag   = (per - 1) / (2 * N)   (Pine integer division)
 */
export function gaussianChannel(
  srcSeries: number[],
  trSeries: number[],
  params: GaussianParams,
): GaussianResult {
  const N = Math.min(9, Math.max(1, Math.round(params.poles)));
  const per = Math.max(2, Math.round(params.period));
  const mult = Math.max(0, params.multiplier);

  const beta = (1 - Math.cos((4 * Math.asin(1)) / per)) / (Math.pow(1.414, 2 / N) - 1);
  const alpha = -beta + Math.sqrt(Math.pow(beta, 2) + 2 * beta);
  const lag = Math.trunc((per - 1) / (2 * N));

  const applyLag = (arr: number[]): number[] => {
    if (!params.reducedLag) return arr.slice();
    const out = new Array<number>(arr.length);
    for (let i = 0; i < arr.length; i++) {
      const prev = i - lag >= 0 ? arr[i - lag] : arr[0];
      out[i] = arr[i] + (arr[i] - prev);
    }
    return out;
  };

  const srcdata = applyLag(srcSeries);
  const trdata = applyLag(trSeries);

  const src = fPole(alpha, srcdata, N);
  const tr = fPole(alpha, trdata, N);

  const filt = new Array<number>(srcSeries.length);
  const filttr = new Array<number>(srcSeries.length);
  for (let i = 0; i < srcSeries.length; i++) {
    filt[i] = params.fastResponse ? (src.fn[i] + src.f1[i]) / 2 : src.fn[i];
    filttr[i] = params.fastResponse ? (tr.fn[i] + tr.f1[i]) / 2 : tr.fn[i];
  }

  const hband = filt.map((v, i) => v + filttr[i] * mult);
  const lband = filt.map((v, i) => v - filttr[i] * mult);

  return { filt, hband, lband, filttr, alpha, beta, lag };
}

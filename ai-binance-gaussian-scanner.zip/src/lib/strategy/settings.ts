export interface StrategySettings {
  // Gaussian channel
  poles: number;
  period: number;
  multiplier: number;
  reducedLag: boolean;
  fastResponse: boolean;
  // Stoch RSI
  stochLength: number;
  rsiLength: number;
  stochK: number;
  stochD: number;
  rsiUpperThreshold: number;
  rsiLowerThreshold: number;
  // Filters
  useRegime: boolean;
  smaLength: number;
  useBullishCandle: boolean;
  breakoutBufferPct: number;
  useStopLoss: boolean;
  // Non-Pine extras (kept strictly separate from the strategy logic)
  useAiTp: boolean;
  riskPct: number;
  commissionPct: number;
}

export const DEFAULT_SETTINGS: StrategySettings = {
  poles: 4,
  period: 89,
  multiplier: 1.5,
  reducedLag: false,
  fastResponse: false,
  stochLength: 14,
  rsiLength: 14,
  stochK: 3,
  stochD: 3,
  rsiUpperThreshold: 80,
  rsiLowerThreshold: 25,
  useRegime: true,
  smaLength: 200,
  useBullishCandle: true,
  breakoutBufferPct: 0,
  useStopLoss: true,
  useAiTp: true,
  riskPct: 1,
  commissionPct: 0.1,
};

const numKeys: (keyof StrategySettings)[] = [
  "poles",
  "period",
  "multiplier",
  "stochLength",
  "rsiLength",
  "stochK",
  "stochD",
  "rsiUpperThreshold",
  "rsiLowerThreshold",
  "smaLength",
  "breakoutBufferPct",
  "riskPct",
  "commissionPct",
];

const boolKeys: (keyof StrategySettings)[] = [
  "reducedLag",
  "fastResponse",
  "useRegime",
  "useBullishCandle",
  "useStopLoss",
  "useAiTp",
];

/** Merge partial/unknown input (query params, JSON body, DB row) into settings. */
export function coerceSettings(input: unknown): StrategySettings {
  const out: StrategySettings = { ...DEFAULT_SETTINGS };
  if (!input || typeof input !== "object") return out;
  const rec = input as Record<string, unknown>;
  for (const k of numKeys) {
    const v = rec[k];
    if (v === undefined || v === null || v === "") continue;
    const n = typeof v === "number" ? v : Number(v);
    if (Number.isFinite(n)) (out[k] as number) = n;
  }
  for (const k of boolKeys) {
    const v = rec[k];
    if (v === undefined || v === null || v === "") continue;
    (out[k] as boolean) = v === true || v === "true" || v === 1 || v === "1";
  }
  out.poles = Math.min(9, Math.max(1, Math.round(out.poles)));
  out.period = Math.max(2, Math.round(out.period));
  out.smaLength = Math.max(2, Math.round(out.smaLength));
  out.stochLength = Math.max(1, Math.round(out.stochLength));
  out.rsiLength = Math.max(1, Math.round(out.rsiLength));
  out.stochK = Math.max(1, Math.round(out.stochK));
  out.stochD = Math.max(1, Math.round(out.stochD));
  out.multiplier = Math.max(0, out.multiplier);
  return out;
}

export function settingsFromSearchParams(sp: URLSearchParams): StrategySettings {
  const obj: Record<string, string> = {};
  sp.forEach((v, k) => {
    obj[k] = v;
  });
  return coerceSettings(obj);
}

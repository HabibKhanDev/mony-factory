import { gaussianChannel } from "./gaussian";
import {
  atr,
  lastValid,
  rsi as rsiFn,
  sma,
  stoch,
  trueRange,
} from "./indicators";
import type { StrategySettings } from "./settings";

export interface Candle {
  /** UNIX seconds (candle open time) */
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  closed: boolean;
}

export type SignalKind = "BUY" | "EXIT" | "WAIT";

export interface StrategySeries {
  filt: number[];
  hband: number[];
  lband: number[];
  sma: number[];
  rsi: number[];
  k: number[];
  d: number[];
  atr: number[];
  longCondition: boolean[];
  closeCondition: boolean[];
  channelGreen: boolean[];
}

export interface BacktestTrade {
  entryIndex: number;
  entryTime: number;
  entryPrice: number;
  exitIndex: number | null;
  exitTime: number | null;
  exitPrice: number | null;
  stop: number;
  reason: "CHANNEL_EXIT" | "STOP_LOSS" | "OPEN";
  pnlPct: number | null;
  equityAfter: number;
}

export interface BacktestResult {
  trades: BacktestTrade[];
  equityCurve: { time: number; equity: number }[];
  stats: {
    totalTrades: number;
    wins: number;
    losses: number;
    winRate: number;
    netPnlPct: number;
    finalEquity: number;
    maxDrawdownPct: number;
    profitFactor: number;
    avgTradePct: number;
    largestWinPct: number;
    largestLossPct: number;
  };
  inPosition: boolean;
  openTrade: BacktestTrade | null;
}

export interface StrategyState {
  index: number;
  time: number;
  close: number;
  open: number;
  high: number;
  low: number;
  volume: number;
  filt: number;
  filtPrev: number;
  hband: number;
  lband: number;
  sma200: number;
  rsi: number;
  k: number;
  d: number;
  atr: number;
  channelGreen: boolean;
  bullRegime: boolean;
  bullishCandle: boolean;
  breakoutThreshold: number;
  breakout: boolean;
  stochTrigger: boolean;
  longCondition: boolean;
  closeCondition: boolean;
  signal: SignalKind;
  inPosition: boolean;
  bandWidthPct: number;
  distanceToUpperPct: number;
  distanceToSmaPct: number;
  volumeRatio: number;
  trendSlopePct: number;
}

export interface StrategyRun {
  candles: Candle[];
  series: StrategySeries;
  state: StrategyState;
  backtest: BacktestResult;
  settings: StrategySettings;
}

function hlc3(c: Candle[]): number[] {
  return c.map((x) => (x.high + x.low + x.close) / 3);
}

/** Runs the exact Pine strategy over an array of candles (last candle should be closed). */
export function runStrategy(
  allCandles: Candle[],
  settings: StrategySettings,
  opts: { commissionPct?: number } = {},
): StrategyRun {
  // The strategy evaluates on closed bars only (process_orders_on_close=false).
  const candles = allCandles.filter((c) => c.closed);
  const n = candles.length;
  const high = candles.map((c) => c.high);
  const low = candles.map((c) => c.low);
  const close = candles.map((c) => c.close);
  const open = candles.map((c) => c.open);
  const volume = candles.map((c) => c.volume);

  const src = hlc3(candles);
  const tr = trueRange(high, low, close);

  const g = gaussianChannel(src, tr, {
    poles: settings.poles,
    period: settings.period,
    multiplier: settings.multiplier,
    reducedLag: settings.reducedLag,
    fastResponse: settings.fastResponse,
  });

  const rsiArr = rsiFn(close, settings.rsiLength);
  const stochRsi = stoch(rsiArr, rsiArr, rsiArr, settings.stochLength);
  const k = sma(stochRsi, settings.stochK);
  const d = sma(k, settings.stochD);
  const sma200 = sma(close, settings.smaLength);
  const atr14 = atr(high, low, close, 14);
  const volSma = sma(volume, 20);

  const longCondition = new Array<boolean>(n).fill(false);
  const closeCondition = new Array<boolean>(n).fill(false);
  const channelGreen = new Array<boolean>(n).fill(false);

  for (let i = 0; i < n; i++) {
    const green = i > 0 ? g.filt[i] > g.filt[i - 1] : false;
    channelGreen[i] = green;
    const bullRegime = !settings.useRegime || (!Number.isNaN(sma200[i]) && close[i] > sma200[i]);
    const bullishCandle = !settings.useBullishCandle || close[i] > open[i];
    const breakoutThreshold = g.hband[i] * (1 + settings.breakoutBufferPct / 100);
    const stochTrigger =
      !Number.isNaN(k[i]) &&
      (k[i] > settings.rsiUpperThreshold || k[i] < settings.rsiLowerThreshold);
    longCondition[i] =
      green &&
      close[i] > breakoutThreshold &&
      stochTrigger &&
      bullRegime &&
      bullishCandle;
    closeCondition[i] =
      close[i] < g.hband[i] || (i > 0 && g.filt[i] < g.filt[i - 1]);
  }

  const backtest = simulate(
    candles,
    { long: longCondition, close: closeCondition, lband: g.lband },
    settings,
    opts.commissionPct ?? settings.commissionPct,
  );

  const i = n - 1;
  const filt = g.filt[i] ?? Number.NaN;
  const filtPrev = g.filt[i - 1] ?? Number.NaN;
  const hband = g.hband[i] ?? Number.NaN;
  const lband = g.lband[i] ?? Number.NaN;
  const smaLast = sma200[i] ?? Number.NaN;
  const bullRegime = !settings.useRegime || (!Number.isNaN(smaLast) && close[i] > smaLast);
  const bullishCandle = !settings.useBullishCandle || close[i] > open[i];
  const breakoutThreshold = hband * (1 + settings.breakoutBufferPct / 100);
  const stochTrigger =
    !Number.isNaN(k[i]) &&
    (k[i] > settings.rsiUpperThreshold || k[i] < settings.rsiLowerThreshold);

  const signal: SignalKind = longCondition[i]
    ? "BUY"
    : backtest.inPosition && closeCondition[i]
      ? "EXIT"
      : "WAIT";

  const volRatio =
    !Number.isNaN(volSma[i]) && volSma[i] > 0 ? volume[i] / volSma[i] : Number.NaN;

  const state: StrategyState = {
    index: i,
    time: candles[i]?.time ?? 0,
    close: close[i],
    open: open[i],
    high: high[i],
    low: low[i],
    volume: volume[i],
    filt,
    filtPrev,
    hband,
    lband,
    sma200: smaLast,
    rsi: rsiArr[i],
    k: k[i],
    d: d[i],
    atr: lastValid(atr14),
    channelGreen: channelGreen[i],
    bullRegime,
    bullishCandle,
    breakoutThreshold,
    breakout: close[i] > breakoutThreshold,
    stochTrigger,
    longCondition: longCondition[i],
    closeCondition: closeCondition[i],
    signal,
    inPosition: backtest.inPosition,
    bandWidthPct: filt > 0 ? ((hband - lband) / filt) * 100 : Number.NaN,
    distanceToUpperPct: hband > 0 ? ((close[i] - hband) / hband) * 100 : Number.NaN,
    distanceToSmaPct: smaLast > 0 ? ((close[i] - smaLast) / smaLast) * 100 : Number.NaN,
    volumeRatio: volRatio,
    trendSlopePct:
      !Number.isNaN(filtPrev) && filtPrev !== 0 ? ((filt - filtPrev) / filtPrev) * 100 : Number.NaN,
  };

  return {
    candles,
    series: {
      filt: g.filt,
      hband: g.hband,
      lband: g.lband,
      sma: sma200,
      rsi: rsiArr,
      k,
      d,
      atr: atr14,
      longCondition,
      closeCondition,
      channelGreen,
    },
    state,
    backtest,
    settings,
  };
}

/**
 * Bar-by-bar simulation matching the Pine strategy settings:
 * pyramiding 0, 100% of equity, orders filled on the next bar's open
 * (process_orders_on_close = false), commission 0.1% per side,
 * stop-loss resting at the lower Gaussian band.
 */
function simulate(
  candles: Candle[],
  sig: { long: boolean[]; close: boolean[]; lband: number[] },
  settings: StrategySettings,
  commissionPct: number,
): BacktestResult {
  const trades: BacktestTrade[] = [];
  const equityCurve: { time: number; equity: number }[] = [];
  let equity = 100; // percentage-based equity (start = 100)
  let position: { entryIndex: number; entryPrice: number; entryTime: number; stop: number } | null =
    null;
  let peak = equity;
  let maxDd = 0;
  const fee = commissionPct / 100;

  for (let i = 1; i < candles.length; i++) {
    const bar = candles[i];
    const prev = i - 1;

    if (position) {
      // Stop resting at the lower band computed on the previous closed bar.
      const stop = sig.lband[prev];
      position.stop = stop;
      if (settings.useStopLoss && Number.isFinite(stop) && bar.low <= stop) {
        const exitPrice = Math.min(stop, bar.open);
        closeTrade(exitPrice, i, bar.time, "STOP_LOSS");
        continue;
      }
      if (sig.close[prev]) {
        closeTrade(bar.open, i, bar.time, "CHANNEL_EXIT");
      }
    }

    if (!position && sig.long[prev]) {
      position = {
        entryIndex: i,
        entryPrice: bar.open,
        entryTime: bar.time,
        stop: sig.lband[prev],
      };
    }

    equityCurve.push({ time: bar.time, equity });
    if (equity > peak) peak = equity;
    const dd = peak > 0 ? ((peak - equity) / peak) * 100 : 0;
    if (dd > maxDd) maxDd = dd;
  }

  function closeTrade(
    exitPrice: number,
    idx: number,
    time: number,
    reason: BacktestTrade["reason"],
  ) {
    if (!position) return;
    const gross = (exitPrice - position.entryPrice) / position.entryPrice;
    const net = (1 + gross) * (1 - fee) * (1 - fee) - 1;
    equity *= 1 + net;
    trades.push({
      entryIndex: position.entryIndex,
      entryTime: position.entryTime,
      entryPrice: position.entryPrice,
      exitIndex: idx,
      exitTime: time,
      exitPrice,
      stop: position.stop,
      reason,
      pnlPct: net * 100,
      equityAfter: equity,
    });
    position = null;
  }

  let openTrade: BacktestTrade | null = null;
  if (position) {
    const p = position as { entryIndex: number; entryPrice: number; entryTime: number; stop: number };
    const last = candles[candles.length - 1];
    openTrade = {
      entryIndex: p.entryIndex,
      entryTime: p.entryTime,
      entryPrice: p.entryPrice,
      exitIndex: null,
      exitTime: null,
      exitPrice: null,
      stop: sig.lband[candles.length - 1],
      reason: "OPEN",
      pnlPct: ((last.close - p.entryPrice) / p.entryPrice) * 100,
      equityAfter: equity,
    };
  }

  const wins = trades.filter((t) => (t.pnlPct ?? 0) > 0);
  const losses = trades.filter((t) => (t.pnlPct ?? 0) <= 0);
  const grossWin = wins.reduce((a, t) => a + (t.pnlPct ?? 0), 0);
  const grossLoss = Math.abs(losses.reduce((a, t) => a + (t.pnlPct ?? 0), 0));

  return {
    trades,
    equityCurve,
    inPosition: openTrade !== null,
    openTrade,
    stats: {
      totalTrades: trades.length,
      wins: wins.length,
      losses: losses.length,
      winRate: trades.length ? (wins.length / trades.length) * 100 : 0,
      netPnlPct: equity - 100,
      finalEquity: equity,
      maxDrawdownPct: maxDd,
      profitFactor: grossLoss > 0 ? grossWin / grossLoss : grossWin > 0 ? Infinity : 0,
      avgTradePct: trades.length
        ? trades.reduce((a, t) => a + (t.pnlPct ?? 0), 0) / trades.length
        : 0,
      largestWinPct: wins.length ? Math.max(...wins.map((t) => t.pnlPct ?? 0)) : 0,
      largestLossPct: losses.length ? Math.min(...losses.map((t) => t.pnlPct ?? 0)) : 0,
    },
  };
}

import type { Candle } from "./strategy/engine";

/**
 * Real Binance market data access.
 * No mock data, no random values: every number here comes from Binance REST.
 * Multiple public hosts are tried in order because some regions block
 * api.binance.com while data-api.binance.vision stays reachable.
 */
const HOSTS = [
  "https://data-api.binance.vision",
  "https://api.binance.com",
  "https://api-gcp.binance.com",
  "https://api1.binance.com",
];

export class BinanceUnavailableError extends Error {
  constructor(message = "Binance live data unavailable.") {
    super(message);
    this.name = "BinanceUnavailableError";
  }
}

export const TIMEFRAMES = ["5m", "15m", "1h", "4h", "1d"] as const;
export type Timeframe = (typeof TIMEFRAMES)[number];

export const TF_MS: Record<string, number> = {
  "1m": 60_000,
  "5m": 300_000,
  "15m": 900_000,
  "30m": 1_800_000,
  "1h": 3_600_000,
  "4h": 14_400_000,
  "1d": 86_400_000,
  "1w": 604_800_000,
};

export function isTimeframe(v: string): v is Timeframe {
  return (TIMEFRAMES as readonly string[]).includes(v);
}

type CacheEntry = { at: number; ttl: number; value: unknown };
const globalCache = globalThis as typeof globalThis & {
  __binanceCache?: Map<string, CacheEntry>;
};
const cache: Map<string, CacheEntry> = (globalCache.__binanceCache ??= new Map());

function getCached<T>(key: string): T | null {
  const hit = cache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > hit.ttl) {
    cache.delete(key);
    return null;
  }
  return hit.value as T;
}

function setCached(key: string, value: unknown, ttl: number) {
  if (cache.size > 800) {
    const oldest = [...cache.entries()].sort((a, b) => a[1].at - b[1].at).slice(0, 200);
    for (const [k] of oldest) cache.delete(k);
  }
  cache.set(key, { at: Date.now(), ttl, value });
}

async function binanceFetch<T>(path: string, timeoutMs = 12_000): Promise<T> {
  let lastError: unknown = null;
  for (const host of HOSTS) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(`${host}${path}`, {
        signal: ctrl.signal,
        cache: "no-store",
        headers: { "User-Agent": "gaussian-scanner/1.0" },
      });
      clearTimeout(timer);
      if (!res.ok) {
        lastError = new Error(`${host}${path} -> HTTP ${res.status}`);
        continue;
      }
      const json = (await res.json()) as T & { code?: number; msg?: string };
      if (json && typeof json === "object" && "code" in json && (json as { code?: number }).code !== undefined) {
        lastError = new Error(String((json as { msg?: string }).msg ?? "Binance error"));
        continue;
      }
      return json as T;
    } catch (err) {
      clearTimeout(timer);
      lastError = err;
    }
  }
  throw new BinanceUnavailableError(
    `Binance live data unavailable. (${lastError instanceof Error ? lastError.message : "network error"})`,
  );
}

export interface Ticker {
  symbol: string;
  lastPrice: number;
  priceChangePercent: number;
  quoteVolume: number;
  volume: number;
  highPrice: number;
  lowPrice: number;
}

const EXCLUDE = /(UP|DOWN|BULL|BEAR)USDT$/;
const STABLES = new Set([
  "USDCUSDT",
  "FDUSDUSDT",
  "TUSDUSDT",
  "BUSDUSDT",
  "USDPUSDT",
  "DAIUSDT",
  "EURUSDT",
  "AEURUSDT",
  "USD1USDT",
]);

/** Live 24h tickers for every spot USDT pair (auto-discovered, never hard-coded). */
export async function getUsdtTickers(): Promise<Ticker[]> {
  const key = "tickers:usdt";
  const cached = getCached<Ticker[]>(key);
  if (cached) return cached;

  const raw = await binanceFetch<
    {
      symbol: string;
      lastPrice: string;
      priceChangePercent: string;
      quoteVolume: string;
      volume: string;
      highPrice: string;
      lowPrice: string;
      count: number;
    }[]
  >("/api/v3/ticker/24hr", 20_000);

  const out: Ticker[] = raw
    .filter(
      (t) =>
        t.symbol.endsWith("USDT") &&
        !EXCLUDE.test(t.symbol) &&
        !STABLES.has(t.symbol) &&
        Number(t.quoteVolume) > 0 &&
        Number(t.lastPrice) > 0,
    )
    .map((t) => ({
      symbol: t.symbol,
      lastPrice: Number(t.lastPrice),
      priceChangePercent: Number(t.priceChangePercent),
      quoteVolume: Number(t.quoteVolume),
      volume: Number(t.volume),
      highPrice: Number(t.highPrice),
      lowPrice: Number(t.lowPrice),
    }))
    .sort((a, b) => b.quoteVolume - a.quoteVolume);

  setCached(key, out, 30_000);
  return out;
}

export async function getTicker(symbol: string): Promise<Ticker | null> {
  const all = await getUsdtTickers();
  const found = all.find((t) => t.symbol === symbol.toUpperCase());
  if (found) return found;
  try {
    const t = await binanceFetch<{
      symbol: string;
      lastPrice: string;
      priceChangePercent: string;
      quoteVolume: string;
      volume: string;
      highPrice: string;
      lowPrice: string;
    }>(`/api/v3/ticker/24hr?symbol=${encodeURIComponent(symbol.toUpperCase())}`);
    return {
      symbol: t.symbol,
      lastPrice: Number(t.lastPrice),
      priceChangePercent: Number(t.priceChangePercent),
      quoteVolume: Number(t.quoteVolume),
      volume: Number(t.volume),
      highPrice: Number(t.highPrice),
      lowPrice: Number(t.lowPrice),
    };
  } catch {
    return null;
  }
}

type RawKline = [
  number, string, string, string, string, string, number, string, number, string, string, string,
];

function toCandles(raw: RawKline[], intervalMs: number): Candle[] {
  const now = Date.now();
  return raw.map((k) => ({
    time: Math.floor(k[0] / 1000),
    open: Number(k[1]),
    high: Number(k[2]),
    low: Number(k[3]),
    close: Number(k[4]),
    volume: Number(k[5]),
    closed: k[0] + intervalMs <= now,
  }));
}

/** Real candles from Binance. Cached briefly per (symbol, interval, limit). */
export async function getKlines(
  symbol: string,
  interval: string,
  limit = 500,
  opts: { startTime?: number; endTime?: number } = {},
): Promise<Candle[]> {
  const sym = symbol.toUpperCase();
  const capped = Math.min(1000, Math.max(10, limit));
  const key = `k:${sym}:${interval}:${capped}:${opts.startTime ?? ""}:${opts.endTime ?? ""}`;
  const cached = getCached<Candle[]>(key);
  if (cached) return cached;

  let path = `/api/v3/klines?symbol=${encodeURIComponent(sym)}&interval=${interval}&limit=${capped}`;
  if (opts.startTime) path += `&startTime=${opts.startTime}`;
  if (opts.endTime) path += `&endTime=${opts.endTime}`;

  const raw = await binanceFetch<RawKline[]>(path);
  const candles = toCandles(raw, TF_MS[interval] ?? 60_000);
  // Historical windows never change; live windows are cached for a fraction of the bar.
  const ttl = opts.endTime && opts.endTime < Date.now() - (TF_MS[interval] ?? 0)
    ? 3_600_000
    : Math.min(60_000, Math.max(10_000, (TF_MS[interval] ?? 60_000) / 20));
  setCached(key, candles, ttl);
  return candles;
}

/** Paged history fetch for backtests over long date ranges. */
export async function getKlineRange(
  symbol: string,
  interval: string,
  startTime: number,
  endTime: number,
  maxBars = 5000,
): Promise<Candle[]> {
  const step = TF_MS[interval] ?? 3_600_000;
  const out: Candle[] = [];
  let cursor = startTime;
  let guard = 0;
  while (cursor < endTime && out.length < maxBars && guard < 20) {
    guard++;
    const batch = await getKlines(symbol, interval, 1000, {
      startTime: cursor,
      endTime: Math.min(endTime, cursor + step * 1000),
    });
    if (!batch.length) break;
    for (const c of batch) {
      if (!out.length || c.time > out[out.length - 1].time) out.push(c);
    }
    const last = batch[batch.length - 1].time * 1000;
    if (last + step <= cursor) break;
    cursor = last + step;
  }
  return out.slice(0, maxBars);
}

/** Simple concurrency-limited map used by the scanner. */
export async function mapLimit<T, R>(
  items: T[],
  limit: number,
  fn: (item: T, index: number) => Promise<R>,
): Promise<R[]> {
  const results = new Array<R>(items.length);
  let cursor = 0;
  const workers = new Array(Math.min(limit, items.length)).fill(0).map(async () => {
    for (;;) {
      const i = cursor++;
      if (i >= items.length) return;
      results[i] = await fn(items[i], i);
    }
  });
  await Promise.all(workers);
  return results;
}

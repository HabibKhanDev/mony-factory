import type { SymbolAnalysis, MtfRow } from "../analysis/analyze";
import { fmt } from "../analysis/structure";
import type { StrategySettings } from "../strategy/settings";

export interface AiExplanation {
  verdict: "BUY" | "EXIT" | "WAIT";
  headline: string;
  reasons: string[];
  blockers: string[];
  invalidation: string[];
  plan: string[];
  llm?: string | null;
}

/** A compact, factual dump of every real calculated value (used as LLM context too). */
export function buildFacts(a: SymbolAnalysis, mtf?: MtfRow[]): string {
  const s = a.state;
  const lines = [
    `SYMBOL ${a.symbol} | TIMEFRAME ${a.timeframe} | closed candles analysed: ${a.candleCount}`,
    `Last closed candle time (UTC): ${new Date(s.time * 1000).toISOString()}`,
    `Price ${fmt(s.close)} | 24h change ${a.change24h === null ? "n/a" : a.change24h.toFixed(2) + "%"} | 24h quote volume ${a.quoteVolume === null ? "n/a" : Math.round(a.quoteVolume).toLocaleString("en-US")} USDT`,
    `Gaussian filter ${fmt(s.filt)} (prev ${fmt(s.filtPrev)}) -> channel ${s.channelGreen ? "GREEN/rising" : "RED/falling"}, slope ${fmt(s.trendSlopePct, 3)}%/bar`,
    `Upper band ${fmt(s.hband)} | Lower band ${fmt(s.lband)} | band width ${fmt(s.bandWidthPct)}% of filter`,
    `Breakout threshold ${fmt(s.breakoutThreshold)} -> close is ${fmt(s.distanceToUpperPct)}% vs upper band (${s.breakout ? "ABOVE" : "BELOW"})`,
    `RSI(${s.rsi ? "" : ""}) ${fmt(s.rsi)} | StochRSI %K ${fmt(s.k)} | %D ${fmt(s.d)} | trigger zone hit: ${s.stochTrigger}`,
    `SMA regime value ${fmt(s.sma200)} -> ${s.bullRegime ? "BULL" : "BEAR"} (price ${fmt(s.distanceToSmaPct)}% vs SMA)`,
    `Bullish entry candle: ${s.bullishCandle} | volume vs 20-SMA: ${fmt(s.volumeRatio)}x | ATR(14) ${fmt(s.atr)}`,
    `Pine longCondition = ${s.longCondition} | Pine closeCondition = ${s.closeCondition} | strategy currently in position: ${s.inPosition}`,
    `Signal: ${s.signal} | AI score ${a.score}/100`,
    `Market structure: ${a.structure}`,
    `Support levels: ${a.support.map((l) => `${fmt(l.price)} (${l.touches}x)`).join(", ") || "none detected"}`,
    `Resistance levels: ${a.resistance.map((l) => `${fmt(l.price)} (${l.touches}x)`).join(", ") || "none detected"}`,
  ];
  if (a.trendline) {
    lines.push(
      `Rising trendline through swing lows ${fmt(a.trendline.p1.price)} -> ${fmt(a.trendline.p2.price)}, projected now at ${fmt(a.trendline.projected.price)}`,
    );
  }
  if (a.downTrendline) {
    lines.push(
      `Falling trendline through swing highs ${fmt(a.downTrendline.p1.price)} -> ${fmt(a.downTrendline.p2.price)}, projected now at ${fmt(a.downTrendline.projected.price)}`,
    );
  }
  if (a.targets) {
    lines.push(
      `AI TP module (not part of Pine strategy): entry ${fmt(a.targets.entry)}, SL ${fmt(a.targets.stopLoss)} (${fmt(a.targets.riskPct)}% risk), TP1 ${fmt(a.targets.tp1)} (${a.targets.rr1.toFixed(2)}R), TP2 ${fmt(a.targets.tp2)} (${a.targets.rr2.toFixed(2)}R), TP3 ${fmt(a.targets.tp3)} (${a.targets.rr3.toFixed(2)}R)`,
    );
  }
  lines.push(
    `Strategy backtest on these ${a.candleCount} candles: ${a.backtest.totalTrades} trades, win rate ${a.backtest.winRate.toFixed(1)}%, net ${a.backtest.netPnlPct.toFixed(2)}%, max DD ${a.backtest.maxDrawdownPct.toFixed(2)}%`,
  );
  if (mtf?.length) {
    lines.push(
      `Multi-timeframe: ${mtf.map((m) => `${m.timeframe}:${m.signal}/${m.trend}/${m.regime}/score ${m.score}`).join(" | ")}`,
    );
  }
  return lines.join("\n");
}

/** Deterministic rule-based explanation derived purely from calculated values. */
export function explain(a: SymbolAnalysis, settings: StrategySettings): AiExplanation {
  const s = a.state;
  const reasons: string[] = [];
  const blockers: string[] = [];
  const invalidation: string[] = [];
  const plan: string[] = [];

  if (s.channelGreen) {
    reasons.push(
      `Gaussian filter is rising (${fmt(s.filt)} vs ${fmt(s.filtPrev)}, ${fmt(s.trendSlopePct, 3)}%/bar) — the Pine \`channelGreen\` gate is TRUE.`,
    );
  } else {
    blockers.push(
      `Gaussian filter is falling (${fmt(s.filt)} vs ${fmt(s.filtPrev)}), so \`channelGreen\` is FALSE — no long is allowed and \`closeCondition\` is satisfied.`,
    );
  }

  if (s.breakout) {
    reasons.push(
      `Close ${fmt(s.close)} is above the breakout threshold ${fmt(s.breakoutThreshold)} (upper band ${fmt(s.hband)} + ${settings.breakoutBufferPct}% buffer) — price is expanding out of the channel.`,
    );
  } else {
    blockers.push(
      `Close ${fmt(s.close)} is still ${fmt(Math.abs(s.distanceToUpperPct))}% below the breakout threshold ${fmt(s.breakoutThreshold)}; the channel has not been broken.`,
    );
  }

  if (s.stochTrigger) {
    reasons.push(
      `StochRSI %K = ${fmt(s.k)} is in the strategy trigger zone (>${settings.rsiUpperThreshold} momentum thrust or <${settings.rsiLowerThreshold} reset).`,
    );
  } else {
    blockers.push(
      `StochRSI %K = ${fmt(s.k)} sits between ${settings.rsiLowerThreshold} and ${settings.rsiUpperThreshold} — neither a momentum thrust nor a reset, so the trigger is FALSE.`,
    );
  }

  if (settings.useRegime) {
    if (s.bullRegime) {
      reasons.push(
        `Regime gate passes: close is ${fmt(s.distanceToSmaPct)}% above the SMA${settings.smaLength} (${fmt(s.sma200)}).`,
      );
    } else {
      blockers.push(
        `Regime gate blocks the trade: close is ${fmt(s.distanceToSmaPct)}% versus the SMA${settings.smaLength} at ${fmt(s.sma200)} (bear regime).`,
      );
    }
  }

  if (settings.useBullishCandle) {
    if (s.bullishCandle) reasons.push(`Entry candle is bullish (close ${fmt(s.close)} > open ${fmt(s.open)}).`);
    else blockers.push(`Entry candle is not bullish (close ${fmt(s.close)} <= open ${fmt(s.open)}), which the strategy requires.`);
  }

  if (Number.isFinite(s.volumeRatio)) {
    (s.volumeRatio >= 1 ? reasons : blockers).push(
      `Volume is ${fmt(s.volumeRatio)}x its 20-bar average — ${s.volumeRatio >= 1.5 ? "strong participation" : s.volumeRatio >= 1 ? "acceptable participation" : "thin participation"}.`,
    );
  }

  reasons.push(`Market structure reads ${a.structure} from real swing pivots.`);

  const nearestRes = a.resistance[0];
  const nearestSup = a.support[0];
  if (nearestRes) reasons.push(`Nearest resistance cluster: ${fmt(nearestRes.price)} (${nearestRes.touches} touches).`);
  if (nearestSup) reasons.push(`Nearest support cluster: ${fmt(nearestSup.price)} (${nearestSup.touches} touches).`);

  invalidation.push(
    `A close back below the upper band ${fmt(s.hband)} triggers the Pine \`closeCondition\` and exits the position.`,
  );
  invalidation.push(`The Gaussian filter turning down (filt < filt[1]) also fires the exit.`);
  if (settings.useStopLoss) {
    invalidation.push(`Hard stop rests at the lower band ${fmt(s.lband)} (${fmt(((s.close - s.lband) / s.close) * 100)}% below price).`);
  }
  if (settings.useRegime) {
    invalidation.push(`Losing the SMA${settings.smaLength} at ${fmt(s.sma200)} removes the bull-regime gate for new entries.`);
  }
  if (nearestSup) invalidation.push(`Structure breaks if support ${fmt(nearestSup.price)} fails on a closing basis.`);

  if (a.targets) {
    plan.push(`Entry reference ${fmt(a.targets.entry)} / stop ${fmt(a.targets.stopLoss)} → risk ${fmt(a.targets.riskPct)}%.`);
    plan.push(
      `AI TP1 ${fmt(a.targets.tp1)} (${a.targets.rr1.toFixed(2)}R), AI TP2 ${fmt(a.targets.tp2)} (${a.targets.rr2.toFixed(2)}R), AI TP3 ${fmt(a.targets.tp3)} (${a.targets.rr3.toFixed(2)}R). Basis: ${a.targets.basis}.`,
    );
    plan.push(`Position sizing at ${settings.riskPct}% account risk ⇒ size = risk capital / ${fmt(a.targets.riskPct)}% stop distance.`);
  }

  const verdict = s.signal;
  const headline =
    verdict === "BUY"
      ? `BUY — all Pine long conditions are TRUE on the last closed ${a.timeframe} candle (AI score ${a.score}/100).`
      : verdict === "EXIT"
        ? `EXIT — the strategy is in a position and \`closeCondition\` is TRUE on ${a.symbol} ${a.timeframe}.`
        : `WAIT — ${blockers.length} of the strategy conditions are not satisfied yet (AI score ${a.score}/100).`;

  return { verdict, headline, reasons, blockers, invalidation, plan };
}

export function explanationToText(e: AiExplanation): string {
  const out: string[] = [e.headline, ""];
  if (e.verdict === "BUY") out.push("**WHY BUY**");
  else if (e.verdict === "EXIT") out.push("**WHY EXIT**");
  else out.push("**WHY WAIT**");
  for (const r of e.reasons) out.push(`• ${r}`);
  if (e.blockers.length) {
    out.push("", e.verdict === "BUY" ? "**RISKS / WEAK POINTS**" : "**BLOCKING CONDITIONS**");
    for (const b of e.blockers) out.push(`• ${b}`);
  }
  out.push("", "**WHAT INVALIDATES THIS SETUP**");
  for (const i of e.invalidation) out.push(`• ${i}`);
  if (e.plan.length) {
    out.push("", "**TRADE PLAN (AI TP module — not part of the Pine strategy)**");
    for (const p of e.plan) out.push(`• ${p}`);
  }
  if (e.llm) out.push("", "**AI NARRATIVE**", e.llm);
  return out.join("\n");
}

/**
 * Optional LLM enrichment. Only runs when an API key is configured;
 * the model is fed the calculated facts and is told never to invent data.
 * Without a key the deterministic engine above is the answer (still real analysis).
 */
export async function llmNarrative(facts: string, question: string): Promise<string | null> {
  const key = process.env.AI_API_KEY || process.env.OPENAI_API_KEY;
  if (!key) return null;
  const base = process.env.AI_API_BASE || "https://api.openai.com/v1";
  const model = process.env.AI_MODEL || "gpt-4o-mini";
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 25_000);
    const res = await fetch(`${base}/chat/completions`, {
      method: "POST",
      signal: ctrl.signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model,
        temperature: 0.2,
        max_tokens: 700,
        messages: [
          {
            role: "system",
            content:
              "You are a professional crypto trading analyst working with a Gaussian Channel + StochRSI strategy. " +
              "You may ONLY use the numeric facts provided. Never invent prices, levels or statistics. " +
              "Be concise, structured and explicit about what would invalidate the setup. This is analysis, not financial advice.",
          },
          { role: "user", content: `CALCULATED FACTS:\n${facts}\n\nQUESTION: ${question}` },
        ],
      }),
    });
    clearTimeout(timer);
    if (!res.ok) return null;
    const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return json.choices?.[0]?.message?.content?.trim() ?? null;
  } catch {
    return null;
  }
}

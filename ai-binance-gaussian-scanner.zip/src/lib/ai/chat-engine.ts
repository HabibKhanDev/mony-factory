import { analyzeSymbol, multiTimeframe } from "../analysis/analyze";
import { fmt } from "../analysis/structure";
import { BinanceUnavailableError, getUsdtTickers, isTimeframe, TIMEFRAMES } from "../binance";
import { applyFilter, scanMarket } from "../scanner";
import type { StrategySettings } from "../strategy/settings";
import { buildFacts, explain, explanationToText, llmNarrative } from "./analyst";
import { SUGGESTIONS, type ChartAction } from "./actions";


export interface ChatReply {
  reply: string;
  actions: ChartAction[];
  symbol: string;
  timeframe: string;
  data?: unknown;
}

function extractSymbol(text: string, known: string[], fallback: string): string {
  const upper = text.toUpperCase();
  const direct = upper.match(/\b([A-Z0-9]{2,12}USDT)\b/);
  if (direct && known.includes(direct[1])) return direct[1];
  if (direct) return direct[1];
  // bare coin name, e.g. "analyze solana" / "analyze sol"
  const words = upper.match(/\b[A-Z]{2,10}\b/g) ?? [];
  for (const w of words) {
    if (["THE", "AND", "BUY", "EXIT", "WAIT", "SHOW", "DRAW", "WHY", "TP", "SL"].includes(w)) continue;
    const cand = `${w}USDT`;
    if (known.includes(cand)) return cand;
  }
  return fallback;
}

function extractTimeframe(text: string, fallback: string): string {
  const m = text.toLowerCase().match(/\b(5m|15m|30m|1h|4h|1d|1w)\b/);
  if (m && isTimeframe(m[1])) return m[1];
  if (/\bdaily\b/i.test(text)) return "1d";
  if (/\bhourly\b/i.test(text)) return "1h";
  return fallback;
}

export async function handleChat(
  message: string,
  ctx: { symbol: string; timeframe: string; settings: StrategySettings },
): Promise<ChatReply> {
  const text = message.trim();
  const lower = text.toLowerCase();
  let known: string[] = [];
  try {
    known = (await getUsdtTickers()).slice(0, 400).map((t) => t.symbol);
  } catch (err) {
    if (err instanceof BinanceUnavailableError) {
      return {
        reply: "Binance live data unavailable. No analysis is possible without real market data — I will not generate substitute numbers.",
        actions: [],
        symbol: ctx.symbol,
        timeframe: ctx.timeframe,
      };
    }
  }

  const symbol = extractSymbol(text, known, ctx.symbol);
  const timeframe = extractTimeframe(text, ctx.timeframe);

  try {
    // ---- Scanner-oriented intents -------------------------------------
    if (/\b(scan binance|scan the market|run a scan|scan market|scan)\b/.test(lower) && !/analy/.test(lower)) {
      const res = await scanMarket(timeframe, ctx.settings, { limit: 40 });
      const buys = applyFilter(res.rows, "BUY");
      const top = res.rows.slice(0, 8);
      const lines = [
        `Scanned ${res.scanned} live Binance USDT pairs on ${timeframe} using the exact Gaussian Channel + StochRSI rules.`,
        `BUY signals: ${buys.length} · breakouts: ${res.rows.filter((r) => r.breakout).length} · bull regime: ${res.rows.filter((r) => r.regime === "BULL").length}`,
        "",
        "**Top AI-ranked setups**",
        ...top.map(
          (r, i) =>
            `${i + 1}. ${r.symbol} — ${r.signal} · score ${r.score} · ${fmt(r.price)} · 24h ${r.change24h.toFixed(2)}% · filt ${r.trend} · %K ${fmt(r.stochK)} · ${r.regime}`,
        ),
      ];
      return { reply: lines.join("\n"), actions: [], symbol, timeframe, data: top };
    }

    if (/(strongest|best|top).*(buy|setup|signal)|find\s+(the\s+)?strongest/.test(lower)) {
      const tf = extractTimeframe(text, ctx.timeframe);
      const res = await scanMarket(tf, ctx.settings, { limit: 50 });
      const buys = applyFilter(res.rows, "BUY");
      const pool = buys.length ? buys : res.rows;
      const best = pool[0];
      if (!best) {
        return {
          reply: `No qualifying rows returned from Binance for ${tf}.`,
          actions: [],
          symbol,
          timeframe: tf,
        };
      }
      const a = await analyzeSymbol(best.symbol, tf, ctx.settings);
      const ex = explain(a, ctx.settings);
      ex.llm = await llmNarrative(buildFacts(a), `Why is ${best.symbol} the strongest ${tf} setup right now?`);
      const header = buys.length
        ? `Strongest live BUY on ${tf}: **${best.symbol}** (AI score ${best.score}/100).`
        : `No pair currently satisfies every Pine long condition on ${tf}. Closest candidate by AI score: **${best.symbol}** (${best.score}/100).`;
      return {
        reply: `${header}\n\n${explanationToText(ex)}`,
        actions: [
          { type: "setSymbol", symbol: best.symbol, timeframe: tf },
          ...tradeActions(a),
        ],
        symbol: best.symbol,
        timeframe: tf,
        data: best,
      };
    }

    if (/gaussian breakout|breakout/.test(lower) && !/why|explain/.test(lower)) {
      const res = await scanMarket(timeframe, ctx.settings, { limit: 50 });
      const breakouts = applyFilter(res.rows, "BREAKOUT").slice(0, 10);
      if (!breakouts.length) {
        return {
          reply: `No pair in the scanned universe is trading above its Gaussian upper band on ${timeframe} right now.`,
          actions: [],
          symbol,
          timeframe,
        };
      }
      return {
        reply: [
          `Live Gaussian upper-band breakouts on ${timeframe}:`,
          ...breakouts.map(
            (r) =>
              `• ${r.symbol} — close ${fmt(r.price)} is ${fmt(r.distanceToUpperPct)}% above upper band ${fmt(r.hband)} · filt ${r.trend} · ${r.signal} · score ${r.score}`,
          ),
        ].join("\n"),
        actions: [],
        symbol,
        timeframe,
        data: breakouts,
      };
    }

    // ---- Symbol-specific drawing intents ------------------------------
    const a = await analyzeSymbol(symbol, timeframe, ctx.settings);

    if (/support|resistance/.test(lower)) {
      const lines = [
        `**${symbol} ${timeframe} — real structure levels** (from swing pivots on ${a.candleCount} closed candles, price ${fmt(a.price)})`,
        "",
        "Resistance:",
        ...a.resistance.map((r) => `• ${fmt(r.price)} (+${(((r.price - a.price) / a.price) * 100).toFixed(2)}%) · ${r.touches} touch(es)`),
        "",
        "Support:",
        ...a.support.map((r) => `• ${fmt(r.price)} (${(((r.price - a.price) / a.price) * 100).toFixed(2)}%) · ${r.touches} touch(es)`),
        "",
        `Gaussian upper band ${fmt(a.state.hband)} and lower band ${fmt(a.state.lband)} act as dynamic resistance/support; SMA${ctx.settings.smaLength} is at ${fmt(a.state.sma200)}.`,
        "",
        "Levels have been drawn on the chart.",
      ];
      return {
        reply: lines.join("\n"),
        actions: [
          { type: "setSymbol", symbol, timeframe },
          {
            type: "levels",
            support: a.support.map((l) => ({ price: l.price, touches: l.touches })),
            resistance: a.resistance.map((l) => ({ price: l.price, touches: l.touches })),
          },
        ],
        symbol,
        timeframe,
        data: { support: a.support, resistance: a.resistance },
      };
    }

    if (/trend\s?line|trendline/.test(lower)) {
      const actions: ChartAction[] = [{ type: "setSymbol", symbol, timeframe }];
      const parts: string[] = [`**${symbol} ${timeframe} — trendlines from real swing pivots**`];
      if (a.trendline) {
        actions.push({ type: "trendline", kind: "UPTREND", p1: a.trendline.p1, p2: a.trendline.p2 });
        parts.push(
          `• Rising support line anchored at swing lows ${fmt(a.trendline.p1.price)} (${new Date(a.trendline.p1.time * 1000).toISOString().slice(0, 16)}Z) and ${fmt(a.trendline.p2.price)} (${new Date(a.trendline.p2.time * 1000).toISOString().slice(0, 16)}Z). Projected value at the last candle: ${fmt(a.trendline.projected.price)} — price is ${a.price > a.trendline.projected.price ? "above" : "below"} it.`,
        );
      }
      if (a.downTrendline) {
        actions.push({ type: "trendline", kind: "DOWNTREND", p1: a.downTrendline.p1, p2: a.downTrendline.p2 });
        parts.push(
          `• Falling resistance line anchored at swing highs ${fmt(a.downTrendline.p1.price)} and ${fmt(a.downTrendline.p2.price)}; projected now at ${fmt(a.downTrendline.projected.price)}.`,
        );
      }
      if (parts.length === 1) parts.push("No valid swing-point trendline could be validated on this timeframe.");
      else parts.push("", "Trendlines drawn on the chart using real candle timestamps.");
      return { reply: parts.join("\n"), actions, symbol, timeframe, data: { up: a.trendline, down: a.downTrendline } };
    }

    if (/(entry|stop\s?loss|\bsl\b|take profit|\btp\b|target)/.test(lower)) {
      if (!a.targets) {
        return {
          reply: `AI TP module is disabled in settings, or the lower band (${fmt(a.state.lband)}) is not below price (${fmt(a.price)}), so no valid risk structure can be calculated.`,
          actions: [{ type: "setSymbol", symbol, timeframe }],
          symbol,
          timeframe,
        };
      }
      const t = a.targets;
      const reply = [
        `**${symbol} ${timeframe} — levels drawn on the chart**`,
        "",
        `Entry reference: ${fmt(t.entry)} ${a.state.inPosition ? "(strategy is currently long from this price)" : "(current close — the Pine entry fires on the next bar open after a valid signal)"}`,
        `Stop loss: ${fmt(t.stopLoss)} — this is the strategy's own lower Gaussian band stop (risk ${fmt(t.riskPct)}%).`,
        "",
        "AI TP module (separate from the Pine strategy, ATR + structure based):",
        `• AI TP1 ${fmt(t.tp1)} (${t.rr1.toFixed(2)}R, +${(((t.tp1 - t.entry) / t.entry) * 100).toFixed(2)}%)`,
        `• AI TP2 ${fmt(t.tp2)} (${t.rr2.toFixed(2)}R, +${(((t.tp2 - t.entry) / t.entry) * 100).toFixed(2)}%)`,
        `• AI TP3 ${fmt(t.tp3)} (${t.rr3.toFixed(2)}R, +${(((t.tp3 - t.entry) / t.entry) * 100).toFixed(2)}%)`,
        `Basis: ${t.basis}. ATR(14) = ${fmt(t.atr)}.`,
        "",
        `The original strategy itself exits on close < upper band ${fmt(a.state.hband)} or a falling filter, and stops at the lower band.`,
      ].join("\n");
      return {
        reply,
        actions: [{ type: "setSymbol", symbol, timeframe }, ...tradeActions(a)],
        symbol,
        timeframe,
        data: t,
      };
    }

    if (/multi[- ]?time|mtf|alignment|all timeframes/.test(lower)) {
      const mtf = await multiTimeframe(symbol, ctx.settings);
      return {
        reply: [
          `**${symbol} — multi-timeframe read (real Binance candles)**`,
          ...mtf.rows.map(
            (r) =>
              `• ${r.timeframe}: ${r.signal} · Gaussian ${r.trend} · RSI ${fmt(r.rsi)} · %K ${fmt(r.stochK)} · ${r.regime} regime · score ${r.score}`,
          ),
          "",
          `Alignment: ${mtf.alignment}% bullish — ${mtf.verdict}.`,
        ].join("\n"),
        actions: [{ type: "setSymbol", symbol, timeframe }],
        symbol,
        timeframe,
        data: mtf,
      };
    }

    // ---- Default: full analysis of the symbol/chart --------------------
    const mtf = await multiTimeframe(symbol, ctx.settings).catch(() => null);
    const ex = explain(a, ctx.settings);
    ex.llm = await llmNarrative(buildFacts(a, mtf?.rows), text || `Analyze ${symbol} on ${timeframe}`);
    const head = [
      `**${symbol} · ${timeframe} · ${fmt(a.price)}** (last closed candle ${new Date(a.state.time * 1000).toISOString().slice(0, 16)}Z)`,
      mtf ? `Multi-timeframe alignment: ${mtf.alignment}% bullish — ${mtf.verdict}.` : "",
    ]
      .filter(Boolean)
      .join("\n") + "\n\n";
    return {
      reply: `${head}${explanationToText(ex)}`,
      actions: [
        { type: "setSymbol", symbol, timeframe },
        {
          type: "levels",
          support: a.support.map((l) => ({ price: l.price, touches: l.touches })),
          resistance: a.resistance.map((l) => ({ price: l.price, touches: l.touches })),
        },
        ...tradeActions(a),
      ],
      symbol,
      timeframe,
      data: { state: a.state, score: a.score },
    };
  } catch (err) {
    if (err instanceof BinanceUnavailableError) {
      return {
        reply: "Binance live data unavailable. I will not fabricate market data — please retry when the feed is reachable.",
        actions: [],
        symbol,
        timeframe,
      };
    }
    return {
      reply: `Analysis failed: ${err instanceof Error ? err.message : "unknown error"}`,
      actions: [],
      symbol,
      timeframe,
    };
  }
}

function tradeActions(a: Awaited<ReturnType<typeof analyzeSymbol>>): ChartAction[] {
  if (!a.targets) return [];
  return [
    {
      type: "trade",
      entry: a.targets.entry,
      stopLoss: a.targets.stopLoss,
      tp1: a.targets.tp1,
      tp2: a.targets.tp2,
      tp3: a.targets.tp3,
    },
  ];
}


export { TIMEFRAMES, SUGGESTIONS };
export type { ChartAction };

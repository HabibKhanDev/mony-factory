/** Chart actions the AI can trigger (shared by server engine and client UI). */
export type ChartAction =
  | { type: "setSymbol"; symbol: string; timeframe: string }
  | {
      type: "levels";
      support: { price: number; touches: number }[];
      resistance: { price: number; touches: number }[];
    }
  | {
      type: "trendline";
      kind: string;
      p1: { time: number; price: number };
      p2: { time: number; price: number };
    }
  | { type: "trade"; entry: number; stopLoss: number; tp1?: number; tp2?: number; tp3?: number }
  | { type: "swings"; points: { time: number; price: number; kind: string }[] }
  | { type: "clear" };

export const SUGGESTIONS = [
  "Analyze BTCUSDT",
  "Scan Binance",
  "Find strongest BUY",
  "Find Gaussian breakout",
  "Show best 15m setup",
  "Why is this BUY?",
  "Show support and resistance",
  "Draw the trendline",
  "Show entry and stop loss",
  "Show TP",
  "Explain this chart",
  "Show multi-timeframe alignment",
];

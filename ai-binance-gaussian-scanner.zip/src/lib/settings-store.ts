import { eq } from "drizzle-orm";
import { db } from "@/db";
import { strategySettings } from "@/db/schema";
import { coerceSettings, DEFAULT_SETTINGS, type StrategySettings } from "./strategy/settings";

const PROFILE = "default";

export async function loadSettings(): Promise<StrategySettings> {
  try {
    const rows = await db
      .select()
      .from(strategySettings)
      .where(eq(strategySettings.profile, PROFILE))
      .limit(1);
    if (!rows.length) return { ...DEFAULT_SETTINGS };
    return coerceSettings(rows[0].data);
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export async function saveSettings(input: unknown): Promise<StrategySettings> {
  const merged = coerceSettings({ ...(await loadSettings()), ...(input as object) });
  const existing = await db
    .select({ id: strategySettings.id })
    .from(strategySettings)
    .where(eq(strategySettings.profile, PROFILE))
    .limit(1);
  if (existing.length) {
    await db
      .update(strategySettings)
      .set({ data: merged, updatedAt: new Date() })
      .where(eq(strategySettings.profile, PROFILE));
  } else {
    await db.insert(strategySettings).values({ profile: PROFILE, data: merged });
  }
  return merged;
}

/** Settings for a request: query-string overrides win over the stored profile. */
export async function settingsForRequest(sp: URLSearchParams): Promise<StrategySettings> {
  const stored = await loadSettings();
  const obj: Record<string, string> = {};
  sp.forEach((v, k) => {
    obj[k] = v;
  });
  return coerceSettings({ ...stored, ...obj });
}

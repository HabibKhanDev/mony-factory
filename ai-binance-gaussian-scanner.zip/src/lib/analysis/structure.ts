import type { Candle, StrategyRun } from "../strategy/engine";

export interface Swing {
  time: number;
  price: number;
  index: number;
  kind: "HIGH" | "LOW";
}

export interface Level {
  price: number;
  touches: number;
  lastTime: number;
  kind: "SUPPORT" | "RESISTANCE";
}

export interface TrendlinePoint {
  time: number;
  price: number;
}

export interface Trendline {
  kind: "UPTREND" | "DOWNTREND";
  p1: TrendlinePoint;
  p2: TrendlinePoint;
  projected: TrendlinePoint;
  slopePerBar: number;
}

/** Pivot swing detection on real candles (left/right lookback). */
export function findSwings(candles: Candle[], lookback = 5): Swing[] {
  const out: Swing[] = [];
  for (let i = lookback; i < candles.length - lookback; i++) {
    let isHigh = true;
    let isLow = true;
    for (let j = i - lookback; j <= i + lookback; j++) {
      if (j === i) continue;
      if (candles[j].high >= candles[i].high) isHigh = false;
      if (candles[j].low <= candles[i].low) isLow = false;
    }
    if (isHigh) out.push({ time: candles[i].time, price: candles[i].high, index: i, kind: "HIGH" });
    if (isLow) out.push({ time: candles[i].time, price: candles[i].low, index: i, kind: "LOW" });
  }
  return out;
}

/** Clusters swing points into horizontal support / resistance levels. */
export function supportResistance(
  candles: Candle[],
  swings: Swing[],
  price: number,
  tolerancePct = 0.6,
): { support: Level[]; resistance: Level[] } {
  const clusters: { price: number; touches: number; lastTime: number; sum: number }[] = [];
  for (const s of swings) {
    const hit = clusters.find(
      (c) => Math.abs(c.price - s.price) / c.price <= tolerancePct / 100,
    );
    if (hit) {
      hit.touches++;
      hit.sum += s.price;
      hit.price = hit.sum / hit.touches;
      hit.lastTime = Math.max(hit.lastTime, s.time);
    } else {
      clusters.push({ price: s.price, touches: 1, lastTime: s.time, sum: s.price });
    }
  }
  const score = (c: { touches: number; lastTime: number }) =>
    c.touches * 1000 + c.lastTime / 1e7;

  const support = clusters
    .filter((c) => c.price < price)
    .sort((a, b) => score(b) - score(a))
    .slice(0, 6)
    .map<Level>((c) => ({
      price: c.price,
      touches: c.touches,
      lastTime: c.lastTime,
      kind: "SUPPORT",
    }))
    .sort((a, b) => b.price - a.price);

  const resistance = clusters
    .filter((c) => c.price > price)
    .sort((a, b) => score(b) - score(a))
    .slice(0, 6)
    .map<Level>((c) => ({
      price: c.price,
      touches: c.touches,
      lastTime: c.lastTime,
      kind: "RESISTANCE",
    }))
    .sort((a, b) => a.price - b.price);

  if (candles.length) {
    // Always include the most recent structural extremes.
    const window = candles.slice(-120);
    const hi = Math.max(...window.map((c) => c.high));
    const lo = Math.min(...window.map((c) => c.low));
    if (hi > price && !resistance.some((r) => Math.abs(r.price - hi) / hi < 0.002)) {
      resistance.push({ price: hi, touches: 1, lastTime: candles[candles.length - 1].time, kind: "RESISTANCE" });
      resistance.sort((a, b) => a.price - b.price);
    }
    if (lo < price && !support.some((r) => Math.abs(r.price - lo) / lo < 0.002)) {
      support.push({ price: lo, touches: 1, lastTime: candles[candles.length - 1].time, kind: "SUPPORT" });
      support.sort((a, b) => b.price - a.price);
    }
  }

  return { support, resistance };
}

/** Trendline through the two most recent significant swing lows (or highs). */
export function buildTrendline(
  candles: Candle[],
  swings: Swing[],
  kind: "UPTREND" | "DOWNTREND",
): Trendline | null {
  const pts = swings
    .filter((s) => (kind === "UPTREND" ? s.kind === "LOW" : s.kind === "HIGH"))
    .slice(-6);
  if (pts.length < 2) return null;

  let best: { a: Swing; b: Swing; score: number } | null = null;
  for (let i = 0; i < pts.length - 1; i++) {
    for (let j = i + 1; j < pts.length; j++) {
      const a = pts[i];
      const b = pts[j];
      if (b.index - a.index < 5) continue;
      const slope = (b.price - a.price) / (b.index - a.index);
      if (kind === "UPTREND" && slope <= 0) continue;
      if (kind === "DOWNTREND" && slope >= 0) continue;
      // Validate: no candle should violate the line badly between the points.
      let violations = 0;
      for (let x = a.index; x <= b.index; x++) {
        const lineVal = a.price + slope * (x - a.index);
        if (kind === "UPTREND" && candles[x].low < lineVal * 0.99) violations++;
        if (kind === "DOWNTREND" && candles[x].high > lineVal * 1.01) violations++;
      }
      const score = b.index - a.index - violations * 8;
      if (!best || score > best.score) best = { a, b, score };
    }
  }
  if (!best) return null;
  const slope = (best.b.price - best.a.price) / (best.b.index - best.a.index);
  const lastIndex = candles.length - 1;
  return {
    kind,
    p1: { time: best.a.time, price: best.a.price },
    p2: { time: best.b.time, price: best.b.price },
    projected: {
      time: candles[lastIndex].time,
      price: best.a.price + slope * (lastIndex - best.a.index),
    },
    slopePerBar: slope,
  };
}

export type MarketStructure = "UPTREND (HH/HL)" | "DOWNTREND (LH/LL)" | "RANGE / TRANSITION";

export function marketStructure(swings: Swing[]): MarketStructure {
  const highs = swings.filter((s) => s.kind === "HIGH").slice(-3);
  const lows = swings.filter((s) => s.kind === "LOW").slice(-3);
  if (highs.length >= 2 && lows.length >= 2) {
    const hh = highs[highs.length - 1].price > highs[highs.length - 2].price;
    const hl = lows[lows.length - 1].price > lows[lows.length - 2].price;
    const lh = highs[highs.length - 1].price < highs[highs.length - 2].price;
    const ll = lows[lows.length - 1].price < lows[lows.length - 2].price;
    if (hh && hl) return "UPTREND (HH/HL)";
    if (lh && ll) return "DOWNTREND (LH/LL)";
  }
  return "RANGE / TRANSITION";
}

export interface AiTargets {
  entry: number;
  stopLoss: number;
  riskPct: number;
  tp1: number;
  tp2: number;
  tp3: number;
  rr1: number;
  rr2: number;
  rr3: number;
  atr: number;
  basis: string;
}

/**
 * AI take-profit module — explicitly NOT part of the Pine strategy
 * (which only has the lower-band stop and the channel exit).
 * Blends R multiples, ATR expansion and real resistance clusters.
 */
export function aiTakeProfit(
  entry: number,
  stopLoss: number,
  atrValue: number,
  resistance: Level[],
): AiTargets | null {
  if (!Number.isFinite(entry) || !Number.isFinite(stopLoss) || stopLoss >= entry) return null;
  const risk = entry - stopLoss;
  const atrv = Number.isFinite(atrValue) ? atrValue : risk;
  const base = [1, 2, 3].map((m) => entry + Math.max(risk * m, atrv * (m * 0.9)));
  const above = resistance.filter((r) => r.price > entry * 1.001).map((r) => r.price);

  const snap = (target: number, used: number[]): number => {
    const near = above.find(
      (r) => Math.abs(r - target) / target < 0.02 && !used.some((u) => Math.abs(u - r) < 1e-9),
    );
    return near ?? target;
  };
  const used: number[] = [];
  const tp1 = snap(base[0], used);
  used.push(tp1);
  const tp2 = Math.max(snap(base[1], used), tp1 * 1.002);
  used.push(tp2);
  const tp3 = Math.max(snap(base[2], used), tp2 * 1.002);

  return {
    entry,
    stopLoss,
    riskPct: (risk / entry) * 100,
    tp1,
    tp2,
    tp3,
    rr1: (tp1 - entry) / risk,
    rr2: (tp2 - entry) / risk,
    rr3: (tp3 - entry) / risk,
    atr: atrv,
    basis:
      above.length > 0
        ? "R-multiples blended with ATR(14) expansion, snapped to real swing resistance clusters"
        : "R-multiples blended with ATR(14) expansion (no resistance cluster overhead)",
  };
}

/**
 * Deterministic AI score (0-100) computed only from real strategy values.
 * No randomness anywhere.
 */
export function aiScore(run: StrategyRun): { score: number; parts: { label: string; value: number; max: number; note: string }[] } {
  const s = run.state;
  const parts: { label: string; value: number; max: number; note: string }[] = [];

  // 1. Gaussian trend direction & slope strength (0-25)
  const slope = Number.isFinite(s.trendSlopePct) ? s.trendSlopePct : 0;
  const slopeScore = s.channelGreen ? Math.min(25, 10 + Math.min(15, Math.abs(slope) * 40)) : Math.max(0, 6 - Math.min(6, Math.abs(slope) * 20));
  parts.push({
    label: "Gaussian trend",
    value: round(slopeScore),
    max: 25,
    note: `${s.channelGreen ? "filt rising" : "filt falling"} (${slope.toFixed(3)}%/bar)`,
  });

  // 2. Breakout above upper band (0-20)
  const dist = Number.isFinite(s.distanceToUpperPct) ? s.distanceToUpperPct : -100;
  const breakoutScore = dist > 0 ? Math.min(20, 12 + dist * 3) : Math.max(0, 10 + dist * 2.5);
  parts.push({
    label: "Upper-band breakout",
    value: round(breakoutScore),
    max: 20,
    note: `close is ${dist.toFixed(2)}% vs upper band`,
  });

  // 3. Regime (0-20)
  const dsma = Number.isFinite(s.distanceToSmaPct) ? s.distanceToSmaPct : 0;
  const regimeScore = s.bullRegime ? Math.min(20, 12 + Math.min(8, dsma / 2)) : Math.max(0, 6 + dsma / 3);
  parts.push({
    label: `SMA${run.settings.smaLength} regime`,
    value: round(regimeScore),
    max: 20,
    note: `${s.bullRegime ? "bull" : "bear"} regime, price ${dsma.toFixed(2)}% vs SMA`,
  });

  // 4. Stoch RSI trigger zone (0-15)
  const k = Number.isFinite(s.k) ? s.k : 50;
  const kScore = s.stochTrigger
    ? k > run.settings.rsiUpperThreshold
      ? 15
      : 11
    : Math.max(0, 8 - Math.abs(k - 50) / 8);
  parts.push({
    label: "Stoch RSI %K",
    value: round(kScore),
    max: 15,
    note: `%K=${fmt(k)} vs thresholds ${run.settings.rsiLowerThreshold}/${run.settings.rsiUpperThreshold}`,
  });

  // 5. Volume confirmation (0-10)
  const vr = Number.isFinite(s.volumeRatio) ? s.volumeRatio : 1;
  const volScore = Math.max(0, Math.min(10, (vr - 0.5) * 6));
  parts.push({
    label: "Volume vs 20-SMA",
    value: round(volScore),
    max: 10,
    note: `${vr.toFixed(2)}x average volume`,
  });

  // 6. Candle & momentum quality (0-10)
  const body = Math.abs(s.close - s.open);
  const range = Math.max(1e-12, s.high - s.low);
  const bodyRatio = body / range;
  const candleScore = (s.bullishCandle ? 5 : 0) + Math.min(5, bodyRatio * 5);
  parts.push({
    label: "Candle quality",
    value: round(candleScore),
    max: 10,
    note: `${s.close > s.open ? "bullish" : "bearish"} close, body/range ${(bodyRatio * 100).toFixed(0)}%`,
  });

  let total = parts.reduce((a, p) => a + p.value, 0);
  if (s.longCondition) total = Math.max(total, 70); // all Pine conditions true
  if (!s.bullRegime && run.settings.useRegime) total = Math.min(total, 45);
  return { score: Math.max(0, Math.min(100, Math.round(total))), parts };
}

function round(v: number) {
  return Math.round(v * 10) / 10;
}

export function fmt(v: number, digits = 2): string {
  if (!Number.isFinite(v)) return "n/a";
  if (Math.abs(v) >= 1000) return v.toLocaleString("en-US", { maximumFractionDigits: 2 });
  if (Math.abs(v) >= 1) return v.toFixed(digits);
  return v.toPrecision(4);
}

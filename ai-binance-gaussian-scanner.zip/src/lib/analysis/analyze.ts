import { getKlines, getTicker, TIMEFRAMES, type Timeframe } from "../binance";
import { runStrategy, type Candle, type StrategyRun } from "../strategy/engine";
import type { StrategySettings } from "../strategy/settings";
import {
  aiScore,
  aiTakeProfit,
  buildTrendline,
  findSwings,
  marketStructure,
  supportResistance,
  type AiTargets,
  type Level,
  type MarketStructure,
  type Swing,
  type Trendline,
} from "./structure";

export interface SymbolAnalysis {
  symbol: string;
  timeframe: string;
  price: number;
  change24h: number | null;
  quoteVolume: number | null;
  state: StrategyRun["state"];
  score: number;
  scoreParts: { label: string; value: number; max: number; note: string }[];
  swings: Swing[];
  support: Level[];
  resistance: Level[];
  trendline: Trendline | null;
  downTrendline: Trendline | null;
  structure: MarketStructure;
  targets: AiTargets | null;
  backtest: StrategyRun["backtest"]["stats"];
  lastTrades: StrategyRun["backtest"]["trades"];
  candleCount: number;
}

export interface MtfRow {
  timeframe: string;
  signal: string;
  trend: "UP" | "DOWN";
  rsi: number;
  stochK: number;
  regime: "BULL" | "BEAR";
  score: number;
  price: number;
}

export const CANDLE_LIMIT = 500;

export async function analyzeSymbol(
  symbol: string,
  timeframe: string,
  settings: StrategySettings,
  candlesInput?: Candle[],
): Promise<SymbolAnalysis> {
  const sym = symbol.toUpperCase();
  const candles = candlesInput ?? (await getKlines(sym, timeframe, CANDLE_LIMIT));
  const run = runStrategy(candles, settings);
  const ticker = await getTicker(sym).catch(() => null);

  const swings = findSwings(run.candles, 5);
  const price = run.state.close;
  const { support, resistance } = supportResistance(run.candles, swings, price);
  const trendline = buildTrendline(run.candles, swings, "UPTREND");
  const downTrendline = buildTrendline(run.candles, swings, "DOWNTREND");
  const { score, parts } = aiScore(run);

  const entry = run.backtest.openTrade?.entryPrice ?? price;
  const stop = Number.isFinite(run.state.lband) ? run.state.lband : price * 0.97;
  const targets = settings.useAiTp ? aiTakeProfit(entry, stop, run.state.atr, resistance) : null;

  return {
    symbol: sym,
    timeframe,
    price,
    change24h: ticker?.priceChangePercent ?? null,
    quoteVolume: ticker?.quoteVolume ?? null,
    state: run.state,
    score,
    scoreParts: parts,
    swings: swings.slice(-20),
    support,
    resistance,
    trendline,
    downTrendline,
    structure: marketStructure(swings),
    targets,
    backtest: run.backtest.stats,
    lastTrades: run.backtest.trades.slice(-8),
    candleCount: run.candles.length,
  };
}

export async function multiTimeframe(
  symbol: string,
  settings: StrategySettings,
): Promise<{ rows: MtfRow[]; alignment: number; verdict: string }> {
  const rows: MtfRow[] = [];
  for (const tf of TIMEFRAMES) {
    try {
      const candles = await getKlines(symbol, tf, CANDLE_LIMIT);
      const run = runStrategy(candles, settings);
      const { score } = aiScore(run);
      rows.push({
        timeframe: tf,
        signal: run.state.signal,
        trend: run.state.channelGreen ? "UP" : "DOWN",
        rsi: run.state.rsi,
        stochK: run.state.k,
        regime: run.state.close > run.state.sma200 ? "BULL" : "BEAR",
        score,
        price: run.state.close,
      });
    } catch {
      // Missing timeframe data is skipped rather than faked.
    }
  }
  const bullish = rows.filter((r) => r.trend === "UP" && r.regime === "BULL").length;
  const alignment = rows.length ? Math.round((bullish / rows.length) * 100) : 0;
  const verdict =
    alignment >= 80
      ? "Strong multi-timeframe bullish alignment"
      : alignment >= 60
        ? "Mostly bullish alignment with some conflict"
        : alignment >= 40
          ? "Mixed / transitional multi-timeframe picture"
          : "Bearish multi-timeframe alignment";
  return { rows, alignment, verdict };
}

export type { Timeframe };

import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import AppShell from "@/components/AppShell";
import { MarketProvider } from "@/components/market-context";
import "./globals.css";

export const metadata: Metadata = {
  title: "TRADLEWARE · AI Gaussian Binance Scanner",
  description:
    "Real Binance market scanner running the Gaussian Channel + StochRSI strategy with AI analysis, charting and paper trading.",
};

export const viewport: Viewport = {
  themeColor: "#080b12",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#080b12] text-slate-200 antialiased">
        <MarketProvider>
          <AppShell>{children}</AppShell>
        </MarketProvider>
      </body>
    </html>
  );
}

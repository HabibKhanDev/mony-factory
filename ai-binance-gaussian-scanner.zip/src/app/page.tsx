"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { useMarket } from "@/components/market-context";
import { Badge, Button, Card, Chip, ErrorBox, Loading, Stat } from "@/components/ui";
import { fmtCompact, fmtNum, fmtPct, fmtPrice, fmtTime, scoreColor, signalBg } from "@/lib/format";
import type { ScanResponse } from "@/lib/types";

interface MtfRow {
  timeframe: string;
  signal: string;
  trend: string;
  rsi: number;
  stochK: number;
  regime: string;
  score: number;
  price: number;
}

interface AnalyzeResponse {
  ok: boolean;
  error?: string;
  analysis?: { price: number; score: number; structure: string; state: { signal: string } };
  mtf?: { rows: MtfRow[]; alignment: number; verdict: string };
  text?: string;
}

interface PerfResponse {
  ok: boolean;
  stats: {
    totalSignals: number;
    buySignals: number;
    exitSignals: number;
    wins: number;
    losses: number;
    winRate: number;
    totalPnlPct: number;
    avgPnlPct: number;
    bestCoin: string | null;
    bestTimeframe: string | null;
    maxDrawdownPct: number;
    active: number;
  };
}

const TIMEFRAMES = ["5m", "15m", "1h", "4h", "1d"];

export default function DashboardPage() {
  const router = useRouter();
  const { symbol, setSymbol, timeframe, setTimeframe } = useMarket();
  const [scan, setScan] = useState<ScanResponse | null>(null);
  const [analysis, setAnalysis] = useState<AnalyzeResponse | null>(null);
  const [perf, setPerf] = useState<PerfResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [scanRes, analyzeRes, perfRes] = await Promise.all([
        fetch(`/api/scan?timeframe=${timeframe}&limit=30`).then((r) => r.json() as Promise<ScanResponse>),
        fetch(`/api/analyze?symbol=${symbol}&timeframe=${timeframe}`).then(
          (r) => r.json() as Promise<AnalyzeResponse>,
        ),
        fetch("/api/performance").then((r) => r.json() as Promise<PerfResponse>),
      ]);
      if (!scanRes.ok) setError(scanRes.error ?? "Binance live data unavailable.");
      setScan(scanRes.ok ? scanRes : null);
      setAnalysis(analyzeRes);
      setPerf(perfRes);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Network error");
    } finally {
      setLoading(false);
    }
  }, [symbol, timeframe]);

  useEffect(() => {
    void load();
  }, [load]);

  const top = scan?.top ?? [];

  return (
    <div className="space-y-3">
      <Card
        title="Live market overview"
        right={
          <Button variant="ghost" onClick={() => void load()}>
            {loading ? "…" : "Refresh"}
          </Button>
        }
      >
        <div className="flex gap-1 overflow-x-auto">
          {TIMEFRAMES.map((tf) => (
            <Chip key={tf} active={tf === timeframe} onClick={() => setTimeframe(tf)}>
              {tf.toUpperCase()}
            </Chip>
          ))}
        </div>
        {scan && (
          <div className="mt-2 grid grid-cols-3 gap-2 sm:grid-cols-6">
            <Stat label="Pairs scanned" value={scan.scanned} sub={fmtTime(scan.generatedAt)} />
            <Stat label="BUY" value={scan.counts.buy} tone="good" />
            <Stat label="EXIT" value={scan.counts.exit} tone="bad" />
            <Stat label="Bull regime" value={scan.counts.bull} />
            <Stat label="Breakouts" value={scan.counts.breakout} tone="warn" />
            <Stat label="High conf." value={scan.counts.highConfidence} tone="good" />
          </div>
        )}
      </Card>

      {error && <ErrorBox message={error} />}
      {loading && !scan && <Loading />}

      <Card
        title="AI Top 10 setups (ranked from real calculations)"
        right={
          <Link href="/scanner" className="text-[10px] text-emerald-400">
            open scanner →
          </Link>
        }
      >
        <div className="space-y-1.5">
          {top.map((r, i) => (
            <button
              key={r.symbol}
              type="button"
              onClick={() => {
                setSymbol(r.symbol);
                router.push("/chart");
              }}
              className="flex w-full items-center justify-between gap-2 rounded-lg border border-slate-800/60 bg-[#0b101c] px-2.5 py-2 text-left"
            >
              <div className="flex min-w-0 items-center gap-2">
                <span className="w-4 text-[10px] text-slate-600">{i + 1}</span>
                <span className="text-xs font-semibold text-slate-100">{r.symbol}</span>
                <Badge className={signalBg(r.signal)}>{r.signal}</Badge>
              </div>
              <div className="flex items-center gap-3 text-[11px] tabular-nums text-slate-400">
                <span className="hidden sm:inline">{fmtPrice(r.price)}</span>
                <span className={r.change24h >= 0 ? "text-emerald-400" : "text-rose-400"}>
                  {fmtPct(r.change24h)}
                </span>
                <span className="hidden sm:inline">{fmtCompact(r.quoteVolume)}</span>
                <span className={`font-bold ${scoreColor(r.score)}`}>{r.score}</span>
              </div>
            </button>
          ))}
          {!top.length && !loading && (
            <p className="text-xs text-slate-500">No scanner rows available.</p>
          )}
        </div>
      </Card>

      <div className="grid gap-3 lg:grid-cols-2">
        <Card title={`Multi-timeframe AI · ${symbol}`}>
          {analysis?.mtf ? (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-[11px] tabular-nums">
                  <thead className="text-[10px] uppercase text-slate-500">
                    <tr>
                      <th className="py-1">TF</th>
                      <th>Gauss</th>
                      <th>Signal</th>
                      <th>RSI</th>
                      <th>%K</th>
                      <th>Regime</th>
                      <th>Score</th>
                    </tr>
                  </thead>
                  <tbody>
                    {analysis.mtf.rows.map((r) => (
                      <tr key={r.timeframe} className="border-t border-slate-800/60">
                        <td className="py-1 font-semibold text-slate-200">{r.timeframe}</td>
                        <td className={r.trend === "UP" ? "text-emerald-400" : "text-rose-400"}>{r.trend}</td>
                        <td>
                          <Badge className={signalBg(r.signal)}>{r.signal}</Badge>
                        </td>
                        <td>{fmtNum(r.rsi, 1)}</td>
                        <td>{fmtNum(r.stochK, 1)}</td>
                        <td className={r.regime === "BULL" ? "text-emerald-400" : "text-slate-500"}>{r.regime}</td>
                        <td className={scoreColor(r.score)}>{r.score}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-2 rounded-lg border border-slate-800/60 bg-[#0b101c] p-2 text-[11px] text-slate-300">
                Alignment <span className="font-bold text-emerald-400">{analysis.mtf.alignment}%</span> bullish —{" "}
                {analysis.mtf.verdict}
              </div>
            </>
          ) : (
            <p className="text-xs text-slate-500">{analysis?.error ?? "Loading multi-timeframe read…"}</p>
          )}
        </Card>

        <Card title="Signal performance (recorded signals)">
          {perf?.ok ? (
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              <Stat label="Total signals" value={perf.stats.totalSignals} />
              <Stat label="BUY / EXIT" value={`${perf.stats.buySignals} / ${perf.stats.exitSignals}`} />
              <Stat label="Active" value={perf.stats.active} />
              <Stat label="Win rate" value={`${fmtNum(perf.stats.winRate, 1)}%`} tone="good" />
              <Stat label="Total P&L" value={fmtPct(perf.stats.totalPnlPct)} tone={perf.stats.totalPnlPct >= 0 ? "good" : "bad"} />
              <Stat label="Max DD" value={`${fmtNum(perf.stats.maxDrawdownPct, 1)}%`} tone="warn" />
              <Stat label="Best coin" value={perf.stats.bestCoin ?? "—"} />
              <Stat label="Best TF" value={perf.stats.bestTimeframe ?? "—"} />
              <Stat label="Avg P&L" value={fmtPct(perf.stats.avgPnlPct)} />
            </div>
          ) : (
            <Loading label="Loading performance…" />
          )}
          <p className="mt-2 text-[10px] text-slate-500">
            Historical / paper results from recorded signals evaluated against real Binance candles. No guarantee of
            future performance.
          </p>
        </Card>
      </div>

      {analysis?.text && (
        <Card title={`AI analysis · ${symbol} ${timeframe}`}>
          <pre className="whitespace-pre-wrap break-words text-[11px] leading-relaxed text-slate-300">
            {analysis.text}
          </pre>
        </Card>
      )}
    </div>
  );
}

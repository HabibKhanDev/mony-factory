"use client";

import Link from "next/link";
import ChatPanel from "@/components/ChatPanel";
import { useMarket } from "@/components/market-context";
import { Card } from "@/components/ui";

export default function ChatPage() {
  const { symbol, timeframe, drawings } = useMarket();
  const hasDrawings =
    drawings.support.length > 0 || drawings.resistance.length > 0 || drawings.trendlines.length > 0 || drawings.trade;

  return (
    <div className="space-y-3">
      <Card title="AI trading assistant">
        <p className="text-[11px] leading-relaxed text-slate-400">
          The assistant is wired to live Binance data, the scanner, the strategy engine, the current chart context (
          <span className="text-emerald-400">
            {symbol} {timeframe}
          </span>
          ) and your signal history. Ask it to analyze a pair, scan the market, find breakouts, or draw levels — the
          drawings are pushed straight onto the chart with real timestamps and prices.
        </p>
        {hasDrawings ? (
          <Link href="/chart" className="mt-2 inline-block text-[11px] text-emerald-400">
            AI drawings are queued → open the chart
          </Link>
        ) : null}
      </Card>

      <ChatPanel height={520} />
    </div>
  );
}

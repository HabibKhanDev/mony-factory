"use client";

import { useCallback, useEffect, useState } from "react";
import ChartPanel from "@/components/ChartPanel";
import ChatPanel from "@/components/ChatPanel";
import { useMarket } from "@/components/market-context";
import { Badge, Button, Card, Chip, ErrorBox, Loading, Stat } from "@/components/ui";
import { fmtNum, fmtPct, fmtPrice, fmtTime, signalBg, scoreColor } from "@/lib/format";
import type { CandlesResponse } from "@/lib/types";

const TIMEFRAMES = ["5m", "15m", "1h", "4h", "1d"];

export default function ChartPage() {
  const { symbol, timeframe, setSymbol, setTimeframe, drawings, applyActions, clearDrawings, toggleSwings } =
    useMarket();
  const [data, setData] = useState<CandlesResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [symbolInput, setSymbolInput] = useState(symbol);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  useEffect(() => setSymbolInput(symbol), [symbol]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/candles?symbol=${symbol}&timeframe=${timeframe}&limit=500`);
      const json = (await res.json()) as CandlesResponse & { error?: string };
      if (!json.ok) {
        setError(json.error ?? "Binance live data unavailable.");
        setData(null);
      } else {
        setData(json);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Network error");
    } finally {
      setLoading(false);
    }
  }, [symbol, timeframe]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const t = setInterval(() => void load(), 60_000);
    return () => clearInterval(t);
  }, [load]);

  useEffect(() => {
    fetch("/api/symbols?limit=30")
      .then((r) => r.json())
      .then((j: { ok: boolean; symbols?: { symbol: string }[] }) => {
        if (j.ok && j.symbols) setSuggestions(j.symbols.map((s) => s.symbol));
      })
      .catch(() => undefined);
  }, []);

  const state = data?.state;

  const drawAll = () => {
    if (!data) return;
    applyActions([
      {
        type: "levels",
        support: data.support.map((l) => ({ price: l.price, touches: l.touches })),
        resistance: data.resistance.map((l) => ({ price: l.price, touches: l.touches })),
      },
      ...(data.trendline
        ? [{ type: "trendline" as const, kind: "UPTREND", p1: data.trendline.p1, p2: data.trendline.p2 }]
        : []),
      ...(data.downTrendline
        ? [
            {
              type: "trendline" as const,
              kind: "DOWNTREND",
              p1: data.downTrendline.p1,
              p2: data.downTrendline.p2,
            },
          ]
        : []),
      ...(data.targets
        ? [
            {
              type: "trade" as const,
              entry: data.targets.entry,
              stopLoss: data.targets.stopLoss,
              tp1: data.targets.tp1,
              tp2: data.targets.tp2,
              tp3: data.targets.tp3,
            },
          ]
        : []),
    ]);
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setSymbol(symbolInput.trim().toUpperCase());
          }}
          className="flex flex-1 gap-2"
        >
          <input
            value={symbolInput}
            onChange={(e) => setSymbolInput(e.target.value.toUpperCase())}
            list="symbol-list"
            className="min-w-0 flex-1 rounded-lg border border-slate-700 bg-[#0b101c] px-3 py-2 text-sm font-semibold tracking-wide text-slate-100 outline-none focus:border-emerald-500/60"
          />
          <datalist id="symbol-list">
            {suggestions.map((s) => (
              <option key={s} value={s} />
            ))}
          </datalist>
          <Button type="submit">Load</Button>
        </form>
        <Button variant="ghost" onClick={() => void load()}>
          {loading ? "…" : "Refresh"}
        </Button>
      </div>

      <div className="flex gap-1 overflow-x-auto">
        {TIMEFRAMES.map((tf) => (
          <Chip key={tf} active={tf === timeframe} onClick={() => setTimeframe(tf)}>
            {tf.toUpperCase()}
          </Chip>
        ))}
        <span className="mx-1 w-px bg-slate-800" />
        <Chip onClick={drawAll}>AI draw all</Chip>
        <Chip active={drawings.showSwings} onClick={toggleSwings}>
          Swings
        </Chip>
        <Chip onClick={clearDrawings}>Clear</Chip>
      </div>

      {error && <ErrorBox message={error} />}

      <ChartPanel data={data} drawings={drawings} height={420} />

      {loading && !data && <Loading />}

      {state && data && (
        <>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            <Stat label="Price" value={fmtPrice(state.close)} sub={fmtTime(state.time)} />
            <Stat
              label="Signal"
              value={<span className={signalBg(state.signal).includes("emerald") ? "text-emerald-400" : state.signal === "EXIT" ? "text-rose-400" : "text-slate-300"}>{state.signal}</span>}
              sub={state.inPosition ? "strategy in position" : "flat"}
            />
            <Stat label="AI Score" value={<span className={scoreColor(data.score)}>{data.score}/100</span>} sub={data.structure} />
            <Stat
              label="Gaussian trend"
              value={state.channelGreen ? "UP" : "DOWN"}
              tone={state.channelGreen ? "good" : "bad"}
              sub={`slope ${fmtNum(state.trendSlopePct, 3)}%/bar`}
            />
            <Stat label="Upper band" value={fmtPrice(state.hband)} sub={`${fmtNum(state.distanceToUpperPct)}% away`} />
            <Stat label="Lower band" value={fmtPrice(state.lband)} sub="strategy stop-loss" />
            <Stat label="RSI" value={fmtNum(state.rsi)} sub={`Stoch %K ${fmtNum(state.k)} / %D ${fmtNum(state.d)}`} />
            <Stat
              label={`SMA${data.settings.smaLength}`}
              value={fmtPrice(state.sma200)}
              tone={state.bullRegime ? "good" : "bad"}
              sub={`${state.bullRegime ? "BULL" : "BEAR"} regime · ${fmtNum(state.distanceToSmaPct)}%`}
            />
            <Stat label="ATR(14)" value={fmtPrice(state.atr)} sub={`band width ${fmtNum(state.bandWidthPct)}%`} />
            <Stat label="Volume" value={`${fmtNum(state.volumeRatio)}x`} sub="vs 20-bar average" />
            <Stat label="Bullish candle" value={state.bullishCandle ? "YES" : "NO"} tone={state.bullishCandle ? "good" : "bad"} />
            <Stat label="Breakout" value={state.breakout ? "YES" : "NO"} tone={state.breakout ? "good" : "default"} sub={`threshold ${fmtPrice(state.breakoutThreshold)}`} />
          </div>

          <div className="grid gap-3 lg:grid-cols-2">
            <Card title="AI TP module (separate from the Pine strategy)">
              {data.targets ? (
                <div className="space-y-1.5 text-xs">
                  <Row label="Entry" value={fmtPrice(data.targets.entry)} />
                  <Row label="Stop loss (lower band)" value={fmtPrice(data.targets.stopLoss)} tone="bad" />
                  <Row label="AI TP1" value={`${fmtPrice(data.targets.tp1)} · ${data.targets.rr1.toFixed(2)}R`} tone="good" />
                  <Row label="AI TP2" value={`${fmtPrice(data.targets.tp2)} · ${data.targets.rr2.toFixed(2)}R`} tone="good" />
                  <Row label="AI TP3" value={`${fmtPrice(data.targets.tp3)} · ${data.targets.rr3.toFixed(2)}R`} tone="good" />
                  <p className="pt-1 text-[10px] text-slate-500">{data.targets.basis}</p>
                </div>
              ) : (
                <p className="text-xs text-slate-500">AI TP disabled in settings or no valid risk structure.</p>
              )}
            </Card>

            <Card title="Structure levels (real swing pivots)">
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <div className="mb-1 text-[10px] uppercase text-rose-400">Resistance</div>
                  {data.resistance.map((r) => (
                    <div key={r.price} className="flex justify-between tabular-nums text-slate-300">
                      <span>{fmtPrice(r.price)}</span>
                      <span className="text-slate-500">{r.touches}x</span>
                    </div>
                  ))}
                </div>
                <div>
                  <div className="mb-1 text-[10px] uppercase text-emerald-400">Support</div>
                  {data.support.map((r) => (
                    <div key={r.price} className="flex justify-between tabular-nums text-slate-300">
                      <span>{fmtPrice(r.price)}</span>
                      <span className="text-slate-500">{r.touches}x</span>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </div>

          <Card
            title="Strategy backtest on the loaded window"
            right={<Badge className="border-slate-700 text-slate-400">{data.candles.length} candles</Badge>}
          >
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-6">
              <Stat label="Trades" value={data.backtest.totalTrades} />
              <Stat label="Win rate" value={`${fmtNum(data.backtest.winRate, 1)}%`} />
              <Stat label="Net P&L" value={fmtPct(data.backtest.netPnlPct)} tone={data.backtest.netPnlPct >= 0 ? "good" : "bad"} />
              <Stat label="Max DD" value={`${fmtNum(data.backtest.maxDrawdownPct, 1)}%`} tone="warn" />
              <Stat label="Profit factor" value={Number.isFinite(data.backtest.profitFactor) ? fmtNum(data.backtest.profitFactor) : "∞"} />
              <Stat label="Avg trade" value={fmtPct(data.backtest.avgTradePct)} />
            </div>
            <p className="mt-2 text-[10px] text-slate-500">
              Historical simulation on real Binance candles with 0.1% commission per side. Past performance does not
              guarantee future results.
            </p>
          </Card>

          <div className="lg:hidden">
            <ChatPanel height={320} />
          </div>
          <div className="hidden lg:block">
            <ChatPanel height={380} />
          </div>
        </>
      )}
    </div>
  );
}

function Row({ label, value, tone }: { label: string; value: string; tone?: "good" | "bad" }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-slate-500">{label}</span>
      <span
        className={`font-semibold tabular-nums ${
          tone === "good" ? "text-emerald-400" : tone === "bad" ? "text-rose-400" : "text-slate-200"
        }`}
      >
        {value}
      </span>
    </div>
  );
}

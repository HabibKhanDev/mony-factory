import { analyzeSymbol, multiTimeframe } from "@/lib/analysis/analyze";
import { buildFacts, explain, explanationToText, llmNarrative } from "@/lib/ai/analyst";
import { BinanceUnavailableError } from "@/lib/binance";
import { settingsForRequest } from "@/lib/settings-store";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const symbol = (sp.get("symbol") ?? "BTCUSDT").toUpperCase();
  const timeframe = sp.get("timeframe") ?? "1h";
  const withMtf = sp.get("mtf") !== "0";

  try {
    const settings = await settingsForRequest(sp);
    const analysis = await analyzeSymbol(symbol, timeframe, settings);
    const mtf = withMtf ? await multiTimeframe(symbol, settings) : null;
    const explanation = explain(analysis, settings);
    explanation.llm = await llmNarrative(
      buildFacts(analysis, mtf?.rows),
      `Give a professional read of ${symbol} on ${timeframe} for this Gaussian Channel strategy.`,
    );
    return Response.json({
      ok: true,
      analysis,
      mtf,
      explanation,
      text: explanationToText(explanation),
      facts: buildFacts(analysis, mtf?.rows),
      settings,
      llmEnabled: Boolean(process.env.AI_API_KEY || process.env.OPENAI_API_KEY),
    });
  } catch (err) {
    return Response.json(
      {
        ok: false,
        error: err instanceof BinanceUnavailableError ? err.message : `Analysis failed: ${err instanceof Error ? err.message : "unknown"}`,
      },
      { status: 503 },
    );
  }
}

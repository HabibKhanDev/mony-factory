import { desc } from "drizzle-orm";
import { db } from "@/db";
import { alertsLog } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(alertsLog).orderBy(desc(alertsLog.id)).limit(50);
  return Response.json({
    ok: true,
    alerts: rows,
    telegramConfigured: Boolean(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID),
  });
}

/** Sends a Telegram alert (server-side only; token never reaches the browser). */
export async function POST(req: Request) {
  const body = (await req.json()) as {
    symbol?: string;
    timeframe?: string;
    kind?: string;
    message?: string;
  };
  const symbol = body.symbol ?? "-";
  const timeframe = body.timeframe ?? "-";
  const kind = body.kind ?? "INFO";
  const message = body.message ?? `${kind} ${symbol} ${timeframe}`;

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  let delivered = false;
  let error: string | null = null;

  if (token && chatId) {
    try {
      const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: chatId, text: message, parse_mode: "Markdown" }),
      });
      delivered = res.ok;
      if (!res.ok) error = `Telegram HTTP ${res.status}`;
    } catch (err) {
      error = err instanceof Error ? err.message : "telegram error";
    }
  } else {
    error = "TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID not configured";
  }

  await db.insert(alertsLog).values({ symbol, timeframe, kind, message, delivered });
  return Response.json({ ok: true, delivered, error });
}

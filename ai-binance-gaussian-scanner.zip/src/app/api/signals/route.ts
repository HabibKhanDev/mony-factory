import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { signals } from "@/db/schema";
import { analyzeSymbol } from "@/lib/analysis/analyze";
import { loadSettings } from "@/lib/settings-store";
import { ensurePaperAccount, updateActiveSignals } from "@/lib/signals-service";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const status = sp.get("status");
  const limit = Math.min(300, Math.max(1, Number(sp.get("limit") ?? 100)));
  const base = db.select().from(signals);
  const rows = status && status !== "ALL"
    ? await base.where(eq(signals.status, status)).orderBy(desc(signals.signalTime)).limit(limit)
    : await base.orderBy(desc(signals.signalTime)).limit(limit);
  return Response.json({ ok: true, signals: rows });
}

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as {
      action?: string;
      symbol?: string;
      timeframe?: string;
      paper?: boolean;
    };

    if (body.action === "refresh") {
      const updated = await updateActiveSignals();
      return Response.json({ ok: true, updated });
    }

    const symbol = (body.symbol ?? "").toUpperCase();
    const timeframe = body.timeframe ?? "1h";
    if (!symbol) return Response.json({ ok: false, error: "symbol required" }, { status: 400 });

    const settings = await loadSettings();
    const a = await analyzeSymbol(symbol, timeframe, settings);
    const paper = Boolean(body.paper);
    let notional: number | null = null;
    if (paper) {
      const acc = await ensurePaperAccount();
      notional = (acc.balance * acc.positionPct) / 100;
    }

    const inserted = await db
      .insert(signals)
      .values({
        symbol,
        timeframe,
        signal: a.state.signal === "EXIT" ? "EXIT" : "BUY",
        status: a.state.signal === "EXIT" ? "EXIT" : "ACTIVE",
        entry: a.price,
        stopLoss: a.targets?.stopLoss ?? a.state.lband,
        tp1: a.targets?.tp1 ?? null,
        tp2: a.targets?.tp2 ?? null,
        tp3: a.targets?.tp3 ?? null,
        aiScore: a.score,
        candleTime: new Date(a.state.time * 1000),
        paper,
        notional,
        qty: notional ? notional / a.price : null,
        meta: {
          rsi: a.state.rsi,
          stochK: a.state.k,
          hband: a.state.hband,
          lband: a.state.lband,
          sma200: a.state.sma200,
          structure: a.structure,
          manual: true,
        },
      })
      .returning();

    return Response.json({ ok: true, signal: inserted[0] });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "failed" },
      { status: 500 },
    );
  }
}

export async function DELETE(req: Request) {
  const sp = new URL(req.url).searchParams;
  const id = Number(sp.get("id"));
  if (Number.isFinite(id) && id > 0) {
    await db.delete(signals).where(eq(signals.id, id));
  } else {
    await db.delete(signals);
  }
  return Response.json({ ok: true });
}

import { BinanceUnavailableError, getKlineRange, TF_MS } from "@/lib/binance";
import { coerceSettings } from "@/lib/strategy/settings";
import { runStrategy } from "@/lib/strategy/engine";
import { loadSettings } from "@/lib/settings-store";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      symbol?: string;
      timeframe?: string;
      start?: string;
      end?: string;
      settings?: Record<string, unknown>;
    };
    const symbol = (body.symbol ?? "BTCUSDT").toUpperCase();
    const timeframe = body.timeframe ?? "1h";
    const step = TF_MS[timeframe] ?? 3_600_000;
    const end = body.end ? new Date(body.end).getTime() : Date.now();
    const start = body.start ? new Date(body.start).getTime() : end - step * 1500;
    if (!Number.isFinite(start) || !Number.isFinite(end) || start >= end) {
      return Response.json({ ok: false, error: "Invalid date range" }, { status: 400 });
    }

    const stored = await loadSettings();
    const settings = coerceSettings({ ...stored, ...(body.settings ?? {}) });

    // Warm-up bars so SMA/Gaussian are valid at the first evaluated candle.
    const warmup = (Math.max(settings.smaLength, settings.period) + 60) * step;
    const candles = await getKlineRange(symbol, timeframe, start - warmup, end, 5000);
    if (candles.length < settings.smaLength + 20) {
      return Response.json(
        { ok: false, error: `Not enough Binance history for ${symbol} ${timeframe} in this range.` },
        { status: 400 },
      );
    }

    const run = runStrategy(candles, settings);
    const inRange = run.backtest.trades.filter((t) => t.entryTime * 1000 >= start);
    const wins = inRange.filter((t) => (t.pnlPct ?? 0) > 0);
    const losses = inRange.filter((t) => (t.pnlPct ?? 0) <= 0);
    const grossWin = wins.reduce((a, t) => a + (t.pnlPct ?? 0), 0);
    const grossLoss = Math.abs(losses.reduce((a, t) => a + (t.pnlPct ?? 0), 0));

    let equity = 100;
    let peak = 100;
    let maxDd = 0;
    const curve: { time: number; equity: number }[] = [];
    for (const t of inRange) {
      equity *= 1 + (t.pnlPct ?? 0) / 100;
      peak = Math.max(peak, equity);
      maxDd = Math.max(maxDd, ((peak - equity) / peak) * 100);
      curve.push({ time: t.exitTime ?? t.entryTime, equity });
    }

    return Response.json({
      ok: true,
      symbol,
      timeframe,
      start,
      end,
      candles: run.candles.length,
      firstCandle: run.candles[0]?.time ?? null,
      lastCandle: run.candles[run.candles.length - 1]?.time ?? null,
      trades: inRange,
      equityCurve: curve,
      settings,
      stats: {
        totalTrades: inRange.length,
        wins: wins.length,
        losses: losses.length,
        winRate: inRange.length ? (wins.length / inRange.length) * 100 : 0,
        netPnlPct: equity - 100,
        maxDrawdownPct: maxDd,
        profitFactor: grossLoss > 0 ? grossWin / grossLoss : grossWin > 0 ? Infinity : 0,
        avgTradePct: inRange.length
          ? inRange.reduce((a, t) => a + (t.pnlPct ?? 0), 0) / inRange.length
          : 0,
        largestWinPct: wins.length ? Math.max(...wins.map((t) => t.pnlPct ?? 0)) : 0,
        largestLossPct: losses.length ? Math.min(...losses.map((t) => t.pnlPct ?? 0)) : 0,
        openPosition: run.backtest.inPosition,
      },
    });
  } catch (err) {
    return Response.json(
      {
        ok: false,
        error: err instanceof BinanceUnavailableError ? err.message : `Backtest failed: ${err instanceof Error ? err.message : "unknown"}`,
      },
      { status: 503 },
    );
  }
}

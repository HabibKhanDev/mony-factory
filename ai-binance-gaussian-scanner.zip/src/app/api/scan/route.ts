import { BinanceUnavailableError, isTimeframe } from "@/lib/binance";
import { applyFilter, applySort, scanMarket, type ScanFilter, type ScanSort } from "@/lib/scanner";
import { settingsForRequest } from "@/lib/settings-store";
import { recordSignals } from "@/lib/signals-service";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const timeframe = sp.get("timeframe") ?? "1h";
  if (!isTimeframe(timeframe)) {
    return Response.json({ ok: false, error: "Unsupported timeframe" }, { status: 400 });
  }
  const limit = Math.min(150, Math.max(5, Number(sp.get("limit") ?? 40)));
  const filter = (sp.get("filter") ?? "ALL") as ScanFilter;
  const sort = (sp.get("sort") ?? "SCORE") as ScanSort;
  const record = sp.get("record") === "1";

  try {
    const settings = await settingsForRequest(sp);
    const result = await scanMarket(timeframe, settings, { limit });
    if (record) {
      await recordSignals(result.rows, timeframe).catch(() => 0);
    }
    const rows = applySort(applyFilter(result.rows, filter), sort);
    return Response.json({
      ok: true,
      timeframe,
      generatedAt: result.generatedAt,
      scanned: result.scanned,
      failed: result.failed,
      counts: {
        buy: result.rows.filter((r) => r.signal === "BUY").length,
        exit: result.rows.filter((r) => r.signal === "EXIT").length,
        wait: result.rows.filter((r) => r.signal === "WAIT").length,
        breakout: result.rows.filter((r) => r.breakout).length,
        bull: result.rows.filter((r) => r.regime === "BULL").length,
        highConfidence: result.rows.filter((r) => r.score >= 70).length,
      },
      top: result.rows.slice(0, 10),
      rows,
      settings,
    });
  } catch (err) {
    return Response.json(
      {
        ok: false,
        error: err instanceof BinanceUnavailableError ? err.message : "Binance live data unavailable.",
      },
      { status: 503 },
    );
  }
}

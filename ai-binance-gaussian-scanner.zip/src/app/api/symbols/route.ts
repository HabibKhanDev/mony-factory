import { BinanceUnavailableError, getUsdtTickers } from "@/lib/binance";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const limit = Math.min(500, Math.max(1, Number(sp.get("limit") ?? 200)));
  const q = (sp.get("q") ?? "").toUpperCase();
  try {
    const tickers = await getUsdtTickers();
    const filtered = q ? tickers.filter((t) => t.symbol.includes(q)) : tickers;
    return Response.json({
      ok: true,
      total: tickers.length,
      symbols: filtered.slice(0, limit),
    });
  } catch (err) {
    return Response.json(
      {
        ok: false,
        error:
          err instanceof BinanceUnavailableError
            ? err.message
            : "Binance live data unavailable.",
      },
      { status: 503 },
    );
  }
}

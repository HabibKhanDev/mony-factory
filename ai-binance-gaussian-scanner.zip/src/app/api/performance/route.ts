import { performance } from "@/lib/signals-service";

export const dynamic = "force-dynamic";

export async function GET() {
  const stats = await performance();
  return Response.json({
    ok: true,
    stats,
    disclaimer:
      "Historical / paper results calculated from recorded signals and real Binance candles. Past performance does not guarantee future results.",
  });
}

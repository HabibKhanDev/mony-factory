import { loadSettings, saveSettings } from "@/lib/settings-store";
import { DEFAULT_SETTINGS } from "@/lib/strategy/settings";

export const dynamic = "force-dynamic";

export async function GET() {
  const settings = await loadSettings();
  return Response.json({ ok: true, settings, defaults: DEFAULT_SETTINGS });
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const settings = await saveSettings(body);
    return Response.json({ ok: true, settings });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "failed to save" },
      { status: 400 },
    );
  }
}

import { analyzeSymbol, CANDLE_LIMIT } from "@/lib/analysis/analyze";
import { BinanceUnavailableError, getKlines } from "@/lib/binance";
import { settingsForRequest } from "@/lib/settings-store";
import { runStrategy } from "@/lib/strategy/engine";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const symbol = (sp.get("symbol") ?? "BTCUSDT").toUpperCase();
  const timeframe = sp.get("timeframe") ?? "1h";
  const limit = Math.min(1000, Math.max(120, Number(sp.get("limit") ?? CANDLE_LIMIT)));

  try {
    const settings = await settingsForRequest(sp);
    const candles = await getKlines(symbol, timeframe, limit);
    const run = runStrategy(candles, settings);
    const analysis = await analyzeSymbol(symbol, timeframe, settings, candles);

    const line = (arr: number[]) =>
      run.candles
        .map((c, i) => ({ time: c.time, value: arr[i] }))
        .filter((p) => Number.isFinite(p.value));

    const markers: { time: number; type: "BUY" | "EXIT"; price: number; reason: string }[] = [];
    for (const t of run.backtest.trades) {
      markers.push({ time: t.entryTime, type: "BUY", price: t.entryPrice, reason: "Long entry (next bar open)" });
      if (t.exitTime && t.exitPrice !== null) {
        markers.push({
          time: t.exitTime,
          type: "EXIT",
          price: t.exitPrice,
          reason: t.reason === "STOP_LOSS" ? "Lower-band stop loss" : "Channel exit",
        });
      }
    }
    if (run.backtest.openTrade) {
      markers.push({
        time: run.backtest.openTrade.entryTime,
        type: "BUY",
        price: run.backtest.openTrade.entryPrice,
        reason: "Open long position",
      });
    }

    return Response.json({
      ok: true,
      symbol,
      timeframe,
      candles: run.candles.map((c) => ({
        time: c.time,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
        volume: c.volume,
      })),
      series: {
        filt: line(run.series.filt),
        hband: line(run.series.hband),
        lband: line(run.series.lband),
        sma: line(run.series.sma),
        rsi: line(run.series.rsi),
        k: line(run.series.k),
        d: line(run.series.d),
      },
      markers,
      state: run.state,
      score: analysis.score,
      scoreParts: analysis.scoreParts,
      structure: analysis.structure,
      support: analysis.support,
      resistance: analysis.resistance,
      swings: analysis.swings,
      trendline: analysis.trendline,
      downTrendline: analysis.downTrendline,
      targets: analysis.targets,
      backtest: run.backtest.stats,
      settings,
    });
  } catch (err) {
    return Response.json(
      {
        ok: false,
        error: err instanceof BinanceUnavailableError ? err.message : "Binance live data unavailable.",
      },
      { status: 503 },
    );
  }
}

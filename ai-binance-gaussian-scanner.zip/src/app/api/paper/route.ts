import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { paperAccount, signals } from "@/db/schema";
import { ensurePaperAccount, updateActiveSignals } from "@/lib/signals-service";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function GET() {
  const account = await ensurePaperAccount();
  const trades = await db
    .select()
    .from(signals)
    .where(eq(signals.paper, true))
    .orderBy(desc(signals.signalTime))
    .limit(100);
  const open = trades.filter((t) => t.status === "ACTIVE");
  const closed = trades.filter((t) => t.pnlPct !== null);
  const realized = closed.reduce((a, t) => a + ((t.notional ?? 0) * (t.pnlPct ?? 0)) / 100, 0);
  return Response.json({
    ok: true,
    account,
    trades,
    summary: {
      openTrades: open.length,
      closedTrades: closed.length,
      realizedPnl: realized,
      equity: account.balance,
      returnPct: account.startingBalance
        ? ((account.balance - account.startingBalance) / account.startingBalance) * 100
        : 0,
    },
    note: "Paper trading only — no orders are ever sent to Binance.",
  });
}

export async function PUT(req: Request) {
  const body = (await req.json()) as {
    startingBalance?: number;
    riskPct?: number;
    positionPct?: number;
    reset?: boolean;
  };
  const acc = await ensurePaperAccount();
  const startingBalance = Number(body.startingBalance ?? acc.startingBalance);
  const updated = await db
    .update(paperAccount)
    .set({
      startingBalance,
      balance: body.reset ? startingBalance : acc.balance,
      riskPct: Number(body.riskPct ?? acc.riskPct),
      positionPct: Number(body.positionPct ?? acc.positionPct),
      updatedAt: new Date(),
    })
    .where(eq(paperAccount.id, acc.id))
    .returning();
  if (body.reset) {
    await db.delete(signals).where(eq(signals.paper, true));
  }
  return Response.json({ ok: true, account: updated[0] });
}

export async function POST() {
  const updated = await updateActiveSignals();
  return Response.json({ ok: true, updated });
}

import { desc } from "drizzle-orm";
import { db } from "@/db";
import { chatMessages } from "@/db/schema";
import { handleChat } from "@/lib/ai/chat-engine";
import { loadSettings } from "@/lib/settings-store";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function GET() {
  const rows = await db
    .select()
    .from(chatMessages)
    .orderBy(desc(chatMessages.id))
    .limit(50);
  return Response.json({ ok: true, messages: rows.reverse() });
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      message?: string;
      symbol?: string;
      timeframe?: string;
    };
    const message = (body.message ?? "").trim();
    if (!message) return Response.json({ ok: false, error: "Empty message" }, { status: 400 });

    const settings = await loadSettings();
    const result = await handleChat(message, {
      symbol: (body.symbol ?? "BTCUSDT").toUpperCase(),
      timeframe: body.timeframe ?? "1h",
      settings,
    });

    await db.insert(chatMessages).values([
      { role: "user", content: message, actions: null },
      { role: "assistant", content: result.reply, actions: result.actions },
    ]);

    return Response.json({ ok: true, ...result });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "chat failed" },
      { status: 500 },
    );
  }
}

export async function DELETE() {
  await db.delete(chatMessages);
  return Response.json({ ok: true });
}

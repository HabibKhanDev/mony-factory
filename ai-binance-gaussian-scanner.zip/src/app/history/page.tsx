"use client";

import { useCallback, useEffect, useState } from "react";
import EquityChart from "@/components/EquityChart";
import { Badge, Button, Card, Chip, Loading, Stat } from "@/components/ui";
import { fmtNum, fmtPct, fmtPrice, fmtTime, signalBg } from "@/lib/format";

interface SignalRow {
  id: number;
  symbol: string;
  timeframe: string;
  signal: string;
  status: string;
  entry: number;
  stopLoss: number | null;
  tp1: number | null;
  tp2: number | null;
  tp3: number | null;
  aiScore: number;
  signalTime: string;
  exitTime: string | null;
  exitPrice: number | null;
  pnlPct: number | null;
  exitReason: string | null;
  paper: boolean;
}

interface Perf {
  totalSignals: number;
  buySignals: number;
  exitSignals: number;
  wins: number;
  losses: number;
  winRate: number;
  totalPnlPct: number;
  avgPnlPct: number;
  bestCoin: string | null;
  bestTimeframe: string | null;
  maxDrawdownPct: number;
  active: number;
  equity: { time: number; equity: number }[];
  byStatus: Record<string, number>;
}

const STATUSES = ["ALL", "ACTIVE", "TP1_HIT", "TP2_HIT", "TP3_HIT", "STOP_LOSS", "EXIT", "EXPIRED"];

const statusStyle = (s: string) => {
  if (s.startsWith("TP")) return "border-emerald-500/40 bg-emerald-500/10 text-emerald-300";
  if (s === "STOP_LOSS") return "border-rose-500/40 bg-rose-500/10 text-rose-300";
  if (s === "ACTIVE") return "border-sky-500/40 bg-sky-500/10 text-sky-300";
  return "border-slate-600/40 bg-slate-600/10 text-slate-300";
};

export default function HistoryPage() {
  const [rows, setRows] = useState<SignalRow[]>([]);
  const [perf, setPerf] = useState<Perf | null>(null);
  const [status, setStatus] = useState("ALL");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const [s, p] = await Promise.all([
      fetch(`/api/signals?status=${status}&limit=200`).then((r) => r.json() as Promise<{ signals: SignalRow[] }>),
      fetch("/api/performance").then((r) => r.json() as Promise<{ stats: Perf }>),
    ]);
    setRows(s.signals ?? []);
    setPerf(p.stats ?? null);
    setLoading(false);
  }, [status]);

  useEffect(() => {
    void load();
  }, [load]);

  const refresh = async () => {
    setRefreshing(true);
    await fetch("/api/signals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "refresh" }),
    });
    await load();
    setRefreshing(false);
  };

  return (
    <div className="space-y-3">
      <Card
        title="Performance (recorded signals evaluated on real candles)"
        right={
          <Button variant="ghost" onClick={refresh} disabled={refreshing}>
            {refreshing ? "Updating…" : "Re-evaluate"}
          </Button>
        }
      >
        {perf ? (
          <>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
              <Stat label="Total signals" value={perf.totalSignals} />
              <Stat label="BUY" value={perf.buySignals} tone="good" />
              <Stat label="EXIT" value={perf.exitSignals} tone="bad" />
              <Stat label="Wins" value={perf.wins} tone="good" />
              <Stat label="Losses" value={perf.losses} tone="bad" />
              <Stat label="Win rate" value={`${fmtNum(perf.winRate, 1)}%`} />
              <Stat label="Total P&L" value={fmtPct(perf.totalPnlPct)} tone={perf.totalPnlPct >= 0 ? "good" : "bad"} />
              <Stat label="Average P&L" value={fmtPct(perf.avgPnlPct)} />
              <Stat label="Best coin" value={perf.bestCoin ?? "—"} />
              <Stat label="Best timeframe" value={perf.bestTimeframe ?? "—"} />
              <Stat label="Max drawdown" value={`${fmtNum(perf.maxDrawdownPct, 1)}%`} tone="warn" />
              <Stat label="Active" value={perf.active} />
            </div>
            <div className="mt-3">
              <EquityChart points={perf.equity} />
            </div>
            <p className="mt-1 text-[10px] text-slate-500">
              These are historical / paper results computed from recorded signals and real Binance candles. They are not
              a promise of future performance.
            </p>
          </>
        ) : (
          <Loading label="Loading performance…" />
        )}
      </Card>

      <div className="flex gap-1 overflow-x-auto">
        {STATUSES.map((s) => (
          <Chip key={s} active={status === s} onClick={() => setStatus(s)}>
            {s.replace("_", " ")}
          </Chip>
        ))}
      </div>

      {loading && <Loading label="Loading signal history…" />}

      {/* Mobile cards */}
      <div className="space-y-2 lg:hidden">
        {rows.map((r) => (
          <div key={r.id} className="rounded-xl border border-slate-800/80 bg-[#0d1220] p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-slate-100">{r.symbol}</span>
                <span className="text-[10px] text-slate-500">{r.timeframe}</span>
                <Badge className={signalBg(r.signal)}>{r.signal}</Badge>
                {r.paper && <Badge className="border-sky-500/40 text-sky-300">PAPER</Badge>}
              </div>
              <Badge className={statusStyle(r.status)}>{r.status.replace("_", " ")}</Badge>
            </div>
            <div className="mt-1 grid grid-cols-3 gap-1 text-[11px] text-slate-400">
              <span>Entry {fmtPrice(r.entry)}</span>
              <span>SL {fmtPrice(r.stopLoss)}</span>
              <span>AI {r.aiScore}</span>
              <span>TP1 {fmtPrice(r.tp1)}</span>
              <span>TP2 {fmtPrice(r.tp2)}</span>
              <span>TP3 {fmtPrice(r.tp3)}</span>
              <span className="col-span-2">{fmtTime(r.signalTime)}</span>
              <span className={(r.pnlPct ?? 0) >= 0 ? "text-emerald-400" : "text-rose-400"}>
                {r.pnlPct === null ? "open" : fmtPct(r.pnlPct)}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Desktop table */}
      <div className="hidden overflow-x-auto rounded-xl border border-slate-800/80 bg-[#0d1220] lg:block">
        <table className="w-full text-left text-[11px] tabular-nums">
          <thead className="bg-slate-900/60 text-[10px] uppercase text-slate-500">
            <tr>
              {[
                "Symbol",
                "TF",
                "Signal",
                "Status",
                "Entry",
                "SL",
                "TP1",
                "TP2",
                "TP3",
                "AI",
                "Signal time",
                "Exit time",
                "Exit price",
                "P&L",
                "Reason",
              ].map((h) => (
                <th key={h} className="px-2 py-2 font-medium">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-slate-800/60">
                <td className="px-2 py-1.5 font-semibold text-slate-100">{r.symbol}</td>
                <td className="px-2 py-1.5">{r.timeframe}</td>
                <td className="px-2 py-1.5">
                  <Badge className={signalBg(r.signal)}>{r.signal}</Badge>
                </td>
                <td className="px-2 py-1.5">
                  <Badge className={statusStyle(r.status)}>{r.status.replace("_", " ")}</Badge>
                </td>
                <td className="px-2 py-1.5">{fmtPrice(r.entry)}</td>
                <td className="px-2 py-1.5">{fmtPrice(r.stopLoss)}</td>
                <td className="px-2 py-1.5">{fmtPrice(r.tp1)}</td>
                <td className="px-2 py-1.5">{fmtPrice(r.tp2)}</td>
                <td className="px-2 py-1.5">{fmtPrice(r.tp3)}</td>
                <td className="px-2 py-1.5">{r.aiScore}</td>
                <td className="px-2 py-1.5 text-slate-500">{fmtTime(r.signalTime)}</td>
                <td className="px-2 py-1.5 text-slate-500">{fmtTime(r.exitTime)}</td>
                <td className="px-2 py-1.5">{fmtPrice(r.exitPrice)}</td>
                <td className={`px-2 py-1.5 ${(r.pnlPct ?? 0) >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                  {r.pnlPct === null ? "—" : fmtPct(r.pnlPct)}
                </td>
                <td className="px-2 py-1.5 text-slate-500">{r.exitReason ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {!loading && rows.length === 0 && (
        <p className="p-4 text-center text-xs text-slate-500">
          No signals recorded yet. Run a scan — every BUY/EXIT the strategy produces is stored here automatically.
        </p>
      )}
    </div>
  );
}

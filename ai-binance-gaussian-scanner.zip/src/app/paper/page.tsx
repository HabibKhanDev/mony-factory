"use client";

import { useCallback, useEffect, useState } from "react";
import { useMarket } from "@/components/market-context";
import { Badge, Button, Card, Chip, Loading, Stat } from "@/components/ui";
import { fmtNum, fmtPct, fmtPrice, fmtTime, signalBg } from "@/lib/format";

interface Account {
  id: number;
  startingBalance: number;
  balance: number;
  riskPct: number;
  positionPct: number;
}

interface Trade {
  id: number;
  symbol: string;
  timeframe: string;
  signal: string;
  status: string;
  entry: number;
  stopLoss: number | null;
  tp1: number | null;
  exitPrice: number | null;
  pnlPct: number | null;
  notional: number | null;
  signalTime: string;
}

interface PaperResponse {
  ok: boolean;
  account: Account;
  trades: Trade[];
  summary: {
    openTrades: number;
    closedTrades: number;
    realizedPnl: number;
    equity: number;
    returnPct: number;
  };
}

const TIMEFRAMES = ["5m", "15m", "1h", "4h", "1d"];

export default function PaperPage() {
  const { symbol } = useMarket();
  const [data, setData] = useState<PaperResponse | null>(null);
  const [sym, setSym] = useState(symbol);
  const [tf, setTf] = useState("1h");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    const j = (await fetch("/api/paper").then((r) => r.json())) as PaperResponse;
    setData(j);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const saveAccount = async (patch: Partial<Account> & { reset?: boolean }) => {
    setBusy(true);
    await fetch("/api/paper", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    await load();
    setBusy(false);
  };

  const openTrade = async () => {
    setBusy(true);
    setMsg(null);
    const res = await fetch("/api/signals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ symbol: sym.toUpperCase(), timeframe: tf, paper: true }),
    });
    const json = (await res.json()) as { ok: boolean; error?: string };
    setMsg(json.ok ? `Paper position opened on ${sym.toUpperCase()} ${tf} using live strategy levels.` : json.error ?? "failed");
    await load();
    setBusy(false);
  };

  const evaluate = async () => {
    setBusy(true);
    await fetch("/api/paper", { method: "POST" });
    await load();
    setBusy(false);
  };

  if (!data) return <Loading label="Loading paper account…" />;

  return (
    <div className="space-y-3">
      <Card
        title="Paper trading (no real orders are ever sent)"
        right={
          <Button variant="ghost" onClick={evaluate} disabled={busy}>
            Update positions
          </Button>
        }
      >
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
          <Stat label="Starting balance" value={`$${fmtNum(data.account.startingBalance)}`} />
          <Stat
            label="Equity"
            value={`$${fmtNum(data.summary.equity)}`}
            tone={data.summary.returnPct >= 0 ? "good" : "bad"}
            sub={fmtPct(data.summary.returnPct)}
          />
          <Stat label="Realized P&L" value={`$${fmtNum(data.summary.realizedPnl)}`} />
          <Stat label="Open trades" value={data.summary.openTrades} />
          <Stat label="Closed trades" value={data.summary.closedTrades} />
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <label className="block">
            <span className="text-[10px] uppercase text-slate-500">Starting balance</span>
            <input
              type="number"
              defaultValue={data.account.startingBalance}
              onBlur={(e) => saveAccount({ startingBalance: Number(e.target.value) })}
              className="mt-0.5 w-full rounded-lg border border-slate-700 bg-[#0b101c] px-2 py-1.5 text-xs text-slate-200"
            />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase text-slate-500">Risk %</span>
            <input
              type="number"
              step={0.1}
              defaultValue={data.account.riskPct}
              onBlur={(e) => saveAccount({ riskPct: Number(e.target.value) })}
              className="mt-0.5 w-full rounded-lg border border-slate-700 bg-[#0b101c] px-2 py-1.5 text-xs text-slate-200"
            />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase text-slate-500">Position size %</span>
            <input
              type="number"
              step={1}
              defaultValue={data.account.positionPct}
              onBlur={(e) => saveAccount({ positionPct: Number(e.target.value) })}
              className="mt-0.5 w-full rounded-lg border border-slate-700 bg-[#0b101c] px-2 py-1.5 text-xs text-slate-200"
            />
          </label>
          <div className="flex items-end">
            <Button
              variant="danger"
              className="w-full"
              onClick={() => saveAccount({ reset: true })}
              disabled={busy}
            >
              Reset account
            </Button>
          </div>
        </div>
      </Card>

      <Card title="Open a paper position from live strategy levels">
        <div className="flex flex-wrap items-end gap-2">
          <label className="block">
            <span className="text-[10px] uppercase text-slate-500">Symbol</span>
            <input
              value={sym}
              onChange={(e) => setSym(e.target.value.toUpperCase())}
              className="mt-0.5 rounded-lg border border-slate-700 bg-[#0b101c] px-2 py-1.5 text-xs text-slate-200"
            />
          </label>
          <div className="flex gap-1">
            {TIMEFRAMES.map((t) => (
              <Chip key={t} active={t === tf} onClick={() => setTf(t)}>
                {t.toUpperCase()}
              </Chip>
            ))}
          </div>
          <Button onClick={openTrade} disabled={busy}>
            Open paper trade
          </Button>
        </div>
        {msg && <p className="mt-2 text-[11px] text-emerald-400">{msg}</p>}
        <p className="mt-2 text-[10px] text-slate-500">
          Entry, stop-loss and AI TP levels are taken from the live strategy calculation on real Binance candles.
          Positions are then evaluated bar-by-bar against real candles.
        </p>
      </Card>

      <Card title="Paper trades">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[11px] tabular-nums">
            <thead className="text-[10px] uppercase text-slate-500">
              <tr>
                <th className="py-1">Symbol</th>
                <th>TF</th>
                <th>Signal</th>
                <th>Status</th>
                <th>Entry</th>
                <th>SL</th>
                <th>TP1</th>
                <th>Size</th>
                <th>Exit</th>
                <th>P&L</th>
                <th>Time</th>
              </tr>
            </thead>
            <tbody>
              {data.trades.map((t) => (
                <tr key={t.id} className="border-t border-slate-800/60">
                  <td className="py-1 font-semibold text-slate-100">{t.symbol}</td>
                  <td>{t.timeframe}</td>
                  <td>
                    <Badge className={signalBg(t.signal)}>{t.signal}</Badge>
                  </td>
                  <td className="text-slate-400">{t.status.replace("_", " ")}</td>
                  <td>{fmtPrice(t.entry)}</td>
                  <td>{fmtPrice(t.stopLoss)}</td>
                  <td>{fmtPrice(t.tp1)}</td>
                  <td>${fmtNum(t.notional ?? 0)}</td>
                  <td>{fmtPrice(t.exitPrice)}</td>
                  <td className={(t.pnlPct ?? 0) >= 0 ? "text-emerald-400" : "text-rose-400"}>
                    {t.pnlPct === null ? "open" : fmtPct(t.pnlPct)}
                  </td>
                  <td className="text-slate-500">{fmtTime(t.signalTime)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!data.trades.length && <p className="p-3 text-xs text-slate-500">No paper trades yet.</p>}
        </div>
      </Card>
    </div>
  );
}

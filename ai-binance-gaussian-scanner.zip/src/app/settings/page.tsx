"use client";

import { useEffect, useState } from "react";
import { Button, Card, ErrorBox, Loading } from "@/components/ui";
import type { StrategySettings } from "@/lib/types";

const NUM_FIELDS: { key: keyof StrategySettings; label: string; step?: number; hint?: string }[] = [
  { key: "poles", label: "Poles (N)", step: 1, hint: "Pine input: 1-9" },
  { key: "period", label: "Sampling period", step: 1 },
  { key: "multiplier", label: "Filtered TR multiplier", step: 0.1 },
  { key: "stochLength", label: "Stochastic length", step: 1 },
  { key: "rsiLength", label: "RSI length", step: 1 },
  { key: "stochK", label: "%K smoothing", step: 1 },
  { key: "stochD", label: "%D smoothing", step: 1 },
  { key: "rsiUpperThreshold", label: "Upper threshold", step: 1 },
  { key: "rsiLowerThreshold", label: "Lower threshold", step: 1 },
  { key: "smaLength", label: "Regime SMA length", step: 1 },
  { key: "breakoutBufferPct", label: "Breakout buffer (%)", step: 0.1 },
  { key: "riskPct", label: "Risk per trade (%)", step: 0.1 },
  { key: "commissionPct", label: "Commission per side (%)", step: 0.01 },
];

const BOOL_FIELDS: { key: keyof StrategySettings; label: string }[] = [
  { key: "reducedLag", label: "Reduced lag mode" },
  { key: "fastResponse", label: "Fast response mode" },
  { key: "useRegime", label: "Use 200-SMA regime gate" },
  { key: "useBullishCandle", label: "Require bullish entry candle" },
  { key: "useStopLoss", label: "Stop-loss at lower band" },
  { key: "useAiTp", label: "AI take-profit module (extra)" },
];

export default function SettingsPage() {
  const [settings, setSettings] = useState<StrategySettings | null>(null);
  const [defaults, setDefaults] = useState<StrategySettings | null>(null);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((j: { settings: StrategySettings; defaults: StrategySettings }) => {
        setSettings(j.settings);
        setDefaults(j.defaults);
      })
      .catch((e) => setError(String(e)));
  }, []);

  const save = async () => {
    if (!settings) return;
    setSaved(false);
    const res = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(settings),
    });
    const json = (await res.json()) as { ok: boolean; settings?: StrategySettings; error?: string };
    if (json.ok && json.settings) {
      setSettings(json.settings);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } else {
      setError(json.error ?? "Save failed");
    }
  };

  if (!settings) return <Loading label="Loading strategy settings…" />;

  return (
    <div className="space-y-3">
      {error && <ErrorBox message={error} />}
      <Card
        title="Strategy inputs (exact Pine inputs)"
        right={
          <div className="flex gap-2">
            {defaults && (
              <Button variant="ghost" onClick={() => setSettings({ ...defaults })}>
                Reset
              </Button>
            )}
            <Button onClick={save}>{saved ? "Saved ✓" : "Save"}</Button>
          </div>
        }
      >
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
          {NUM_FIELDS.map((f) => (
            <label key={String(f.key)} className="block">
              <span className="text-[10px] uppercase tracking-wide text-slate-500">{f.label}</span>
              <input
                type="number"
                step={f.step ?? 1}
                value={String(settings[f.key])}
                onChange={(e) =>
                  setSettings({ ...settings, [f.key]: Number(e.target.value) } as StrategySettings)
                }
                className="mt-0.5 w-full rounded-lg border border-slate-700 bg-[#0b101c] px-2 py-1.5 text-xs text-slate-200 outline-none focus:border-emerald-500/60"
              />
            </label>
          ))}
        </div>

        <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {BOOL_FIELDS.map((f) => (
            <label
              key={String(f.key)}
              className="flex items-center justify-between rounded-lg border border-slate-800/70 bg-[#0b101c] px-2.5 py-2 text-xs"
            >
              <span className="text-slate-300">{f.label}</span>
              <input
                type="checkbox"
                checked={Boolean(settings[f.key])}
                onChange={(e) =>
                  setSettings({ ...settings, [f.key]: e.target.checked } as StrategySettings)
                }
                className="h-4 w-4 accent-emerald-500"
              />
            </label>
          ))}
        </div>

        <p className="mt-3 text-[10px] leading-relaxed text-slate-500">
          These settings are persisted in PostgreSQL and used by the scanner, chart, AI analysis, chat and backtests.
          The default values match the original Pine script (poles 4, period 89, multiplier 1.5, StochRSI 14/14/3/3,
          thresholds 80/25, 200-SMA regime gate, bullish candle requirement, lower-band stop-loss).
        </p>
      </Card>

      <Card title="Security / environment">
        <ul className="space-y-1 text-[11px] text-slate-400">
          <li>• BINANCE_API_KEY / BINANCE_API_SECRET — optional; only public market endpoints are used.</li>
          <li>• AI_API_KEY (or OPENAI_API_KEY) — enables the optional LLM narrative layer on top of the calculations.</li>
          <li>• TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID — enables Telegram alerts, sent server-side only.</li>
          <li>• DATABASE_URL — PostgreSQL storage for settings, signals, paper trades, chat and alerts.</li>
          <li className="text-slate-500">
            Secrets are read exclusively on the server. Automated real-money trading is intentionally not implemented.
          </li>
        </ul>
      </Card>
    </div>
  );
}

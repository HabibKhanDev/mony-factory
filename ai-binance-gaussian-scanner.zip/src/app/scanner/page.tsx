"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { useMarket } from "@/components/market-context";
import { Badge, Button, Card, Chip, ErrorBox, Loading, Stat } from "@/components/ui";
import { fmtCompact, fmtNum, fmtPct, fmtPrice, fmtTime, scoreColor, signalBg } from "@/lib/format";
import type { ScanResponse, ScanRow } from "@/lib/types";

const TIMEFRAMES = ["5m", "15m", "1h", "4h", "1d"];
const FILTERS = [
  ["ALL", "All"],
  ["BUY", "Buy"],
  ["EXIT", "Exit"],
  ["WAIT", "Wait"],
  ["HIGH_CONFIDENCE", "High confidence"],
  ["BULLISH", "Bullish"],
  ["BEARISH", "Bearish"],
  ["BREAKOUT", "Breakout"],
  ["HIGH_VOLUME", "High volume"],
] as const;
const SORTS = [
  ["SCORE", "AI score"],
  ["VOLUME", "Volume"],
  ["CHANGE", "24h change"],
  ["TREND", "Trend strength"],
] as const;

export default function ScannerPage() {
  const router = useRouter();
  const { timeframe, setTimeframe, setSymbol } = useMarket();
  const [filter, setFilter] = useState<string>("ALL");
  const [sort, setSort] = useState<string>("SCORE");
  const [limit, setLimit] = useState(40);
  const [data, setData] = useState<ScanResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [autoScan, setAutoScan] = useState(false);
  const [notify, setNotify] = useState(false);
  const alerted = useRef<Set<string>>(new Set());

  const scan = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(
        `/api/scan?timeframe=${timeframe}&limit=${limit}&filter=${filter}&sort=${sort}&record=1`,
      );
      const json = (await res.json()) as ScanResponse;
      if (!json.ok) {
        setError(json.error ?? "Binance live data unavailable.");
        setData(null);
      } else {
        setData(json);
        if (notify && typeof Notification !== "undefined" && Notification.permission === "granted") {
          for (const r of json.rows.filter((x) => x.signal === "BUY")) {
            const key = `${r.symbol}-${r.candleTime}`;
            if (alerted.current.has(key)) continue;
            alerted.current.add(key);
            new Notification(`${r.signal} ${r.symbol} ${json.timeframe}`, {
              body: `AI score ${r.score}/100 · price ${fmtPrice(r.price)} · SL ${fmtPrice(r.stopLoss)}`,
            });
            void fetch("/api/alerts", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                symbol: r.symbol,
                timeframe: json.timeframe,
                kind: r.score >= 75 ? "HIGH_CONFIDENCE_BUY" : "BUY",
                message: `*${r.signal} ${r.symbol}* ${json.timeframe}\nPrice ${fmtPrice(r.price)}\nAI score ${r.score}/100\nSL ${fmtPrice(r.stopLoss)} · TP1 ${fmtPrice(r.tp1)}`,
              }),
            });
          }
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Network error");
    } finally {
      setLoading(false);
    }
  }, [timeframe, limit, filter, sort, notify]);

  useEffect(() => {
    void scan();
  }, [scan]);

  useEffect(() => {
    if (!autoScan) return;
    const id = setInterval(() => void scan(), 120_000);
    return () => clearInterval(id);
  }, [autoScan, scan]);

  const openSymbol = (row: ScanRow) => {
    setSymbol(row.symbol);
    setTimeframe(timeframe);
    router.push("/chart");
  };

  return (
    <div className="space-y-3">
      <Card
        title="Binance USDT market scanner"
        right={
          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => setAutoScan((v) => !v)}>
              {autoScan ? "Auto: ON" : "Auto: OFF"}
            </Button>
            <Button onClick={() => void scan()} disabled={loading}>
              {loading ? "Scanning…" : "Start scan"}
            </Button>
          </div>
        }
      >
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex gap-1 overflow-x-auto">
            {TIMEFRAMES.map((tf) => (
              <Chip key={tf} active={tf === timeframe} onClick={() => setTimeframe(tf)}>
                {tf.toUpperCase()}
              </Chip>
            ))}
          </div>
          <select
            value={limit}
            onChange={(e) => setLimit(Number(e.target.value))}
            className="rounded-lg border border-slate-700 bg-[#0b101c] px-2 py-1 text-[11px] text-slate-300"
          >
            {[20, 40, 60, 100, 150].map((n) => (
              <option key={n} value={n}>
                Top {n} by volume
              </option>
            ))}
          </select>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="rounded-lg border border-slate-700 bg-[#0b101c] px-2 py-1 text-[11px] text-slate-300"
          >
            {SORTS.map(([v, l]) => (
              <option key={v} value={v}>
                Sort: {l}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={async () => {
              if (typeof Notification === "undefined") return;
              const perm = await Notification.requestPermission();
              setNotify(perm === "granted");
            }}
            className={`rounded-lg border px-2 py-1 text-[11px] ${
              notify ? "border-emerald-500/50 text-emerald-300" : "border-slate-700 text-slate-400"
            }`}
          >
            {notify ? "Alerts ON" : "Enable alerts"}
          </button>
        </div>

        <div className="mt-2 flex gap-1 overflow-x-auto pb-1">
          {FILTERS.map(([v, l]) => (
            <Chip key={v} active={filter === v} onClick={() => setFilter(v)}>
              {l}
            </Chip>
          ))}
        </div>
      </Card>

      {error && <ErrorBox message={error} />}
      {loading && !data && <Loading label="Loading real Binance symbols and candles…" />}

      {data && (
        <>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
            <Stat label="Scanned" value={data.scanned} sub={`${data.timeframe} · ${fmtTime(data.generatedAt)}`} />
            <Stat label="BUY" value={data.counts.buy} tone="good" />
            <Stat label="EXIT" value={data.counts.exit} tone="bad" />
            <Stat label="WAIT" value={data.counts.wait} />
            <Stat label="Breakouts" value={data.counts.breakout} tone="warn" />
            <Stat label="High conf." value={data.counts.highConfidence} tone="good" />
          </div>

          {/* Mobile cards */}
          <div className="space-y-2 lg:hidden">
            {data.rows.map((r) => (
              <button
                key={r.symbol}
                type="button"
                onClick={() => openSymbol(r)}
                className="w-full rounded-xl border border-slate-800/80 bg-[#0d1220] p-3 text-left"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-slate-100">{r.symbol}</span>
                    <Badge className={signalBg(r.signal)}>{r.signal}</Badge>
                    {r.breakout && <Badge className="border-amber-500/40 bg-amber-500/10 text-amber-300">BRK</Badge>}
                  </div>
                  <span className={`text-sm font-bold ${scoreColor(r.score)}`}>{r.score}</span>
                </div>
                <div className="mt-1 grid grid-cols-3 gap-1 text-[11px] text-slate-400">
                  <span className="text-slate-200">{fmtPrice(r.price)}</span>
                  <span className={r.change24h >= 0 ? "text-emerald-400" : "text-rose-400"}>
                    {fmtPct(r.change24h)}
                  </span>
                  <span>{fmtCompact(r.quoteVolume)} USDT</span>
                  <span>Gauss {r.trend}</span>
                  <span>%K {fmtNum(r.stochK, 1)}</span>
                  <span>RSI {fmtNum(r.rsi, 1)}</span>
                  <span>{r.regime}</span>
                  <span>H {fmtPrice(r.hband)}</span>
                  <span>L {fmtPrice(r.lband)}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Desktop table */}
          <div className="hidden overflow-x-auto rounded-xl border border-slate-800/80 bg-[#0d1220] lg:block">
            <table className="w-full text-left text-[11px]">
              <thead className="bg-slate-900/60 text-[10px] uppercase tracking-wide text-slate-500">
                <tr>
                  {[
                    "Symbol",
                    "Price",
                    "24h",
                    "Volume",
                    "Gauss",
                    "Upper",
                    "Lower",
                    "%K",
                    "RSI",
                    "SMA",
                    "Regime",
                    "Bull candle",
                    "Breakout",
                    "Signal",
                    "AI",
                  ].map((h) => (
                    <th key={h} className="px-2 py-2 font-medium">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.rows.map((r) => (
                  <tr
                    key={r.symbol}
                    onClick={() => openSymbol(r)}
                    className="cursor-pointer border-t border-slate-800/60 tabular-nums hover:bg-slate-800/40"
                  >
                    <td className="px-2 py-1.5 font-semibold text-slate-100">{r.symbol}</td>
                    <td className="px-2 py-1.5">{fmtPrice(r.price)}</td>
                    <td className={`px-2 py-1.5 ${r.change24h >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                      {fmtPct(r.change24h)}
                    </td>
                    <td className="px-2 py-1.5">{fmtCompact(r.quoteVolume)}</td>
                    <td className={`px-2 py-1.5 ${r.trend === "UP" ? "text-emerald-400" : "text-rose-400"}`}>
                      {r.trend}
                    </td>
                    <td className="px-2 py-1.5">{fmtPrice(r.hband)}</td>
                    <td className="px-2 py-1.5">{fmtPrice(r.lband)}</td>
                    <td className="px-2 py-1.5">{fmtNum(r.stochK, 1)}</td>
                    <td className="px-2 py-1.5">{fmtNum(r.rsi, 1)}</td>
                    <td className="px-2 py-1.5">{fmtPrice(r.sma200)}</td>
                    <td className={`px-2 py-1.5 ${r.regime === "BULL" ? "text-emerald-400" : "text-slate-500"}`}>
                      {r.regime}
                    </td>
                    <td className="px-2 py-1.5">{r.bullishCandle ? "✓" : "—"}</td>
                    <td className="px-2 py-1.5">{r.breakout ? "✓" : "—"}</td>
                    <td className="px-2 py-1.5">
                      <Badge className={signalBg(r.signal)}>{r.signal}</Badge>
                    </td>
                    <td className={`px-2 py-1.5 font-bold ${scoreColor(r.score)}`}>{r.score}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {data.rows.length === 0 && (
            <p className="p-4 text-center text-xs text-slate-500">
              No pair matches this filter on {data.timeframe} right now. Nothing is fabricated — the scanner only
              reports what the strategy actually computes.
            </p>
          )}
        </>
      )}
    </div>
  );
}

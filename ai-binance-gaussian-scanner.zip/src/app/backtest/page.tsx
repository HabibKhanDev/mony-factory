"use client";

import { useEffect, useState } from "react";
import EquityChart from "@/components/EquityChart";
import { useMarket } from "@/components/market-context";
import { Button, Card, Chip, ErrorBox, Loading, Stat } from "@/components/ui";
import { fmtNum, fmtPct, fmtPrice, fmtTime } from "@/lib/format";
import type { StrategySettings } from "@/lib/types";

interface Trade {
  entryTime: number;
  entryPrice: number;
  exitTime: number | null;
  exitPrice: number | null;
  reason: string;
  pnlPct: number | null;
}

interface BacktestResponse {
  ok: boolean;
  error?: string;
  symbol: string;
  timeframe: string;
  candles: number;
  firstCandle: number | null;
  lastCandle: number | null;
  trades: Trade[];
  equityCurve: { time: number; equity: number }[];
  stats: {
    totalTrades: number;
    wins: number;
    losses: number;
    winRate: number;
    netPnlPct: number;
    maxDrawdownPct: number;
    profitFactor: number;
    avgTradePct: number;
    largestWinPct: number;
    largestLossPct: number;
    openPosition: boolean;
  };
}

const TIMEFRAMES = ["5m", "15m", "1h", "4h", "1d"];

export default function BacktestPage() {
  const { symbol } = useMarket();
  const [sym, setSym] = useState(symbol);
  const [tf, setTf] = useState("1h");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [settings, setSettings] = useState<StrategySettings | null>(null);
  const [result, setResult] = useState<BacktestResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const now = new Date();
    const past = new Date(now.getTime() - 90 * 86_400_000);
    setEnd(now.toISOString().slice(0, 10));
    setStart(past.toISOString().slice(0, 10));
    fetch("/api/settings")
      .then((r) => r.json())
      .then((j: { settings: StrategySettings }) => setSettings(j.settings))
      .catch(() => undefined);
  }, []);

  const run = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/backtest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol: sym.toUpperCase(),
          timeframe: tf,
          start,
          end,
          settings: settings ?? undefined,
        }),
      });
      const json = (await res.json()) as BacktestResponse;
      if (!json.ok) {
        setError(json.error ?? "Backtest failed");
        setResult(null);
      } else {
        setResult(json);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Network error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-3">
      <Card title="Backtest the exact strategy on real Binance history">
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          <label className="block">
            <span className="text-[10px] uppercase text-slate-500">Symbol</span>
            <input
              value={sym}
              onChange={(e) => setSym(e.target.value.toUpperCase())}
              className="mt-0.5 w-full rounded-lg border border-slate-700 bg-[#0b101c] px-2 py-1.5 text-xs text-slate-200"
            />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase text-slate-500">Start date</span>
            <input
              type="date"
              value={start}
              onChange={(e) => setStart(e.target.value)}
              className="mt-0.5 w-full rounded-lg border border-slate-700 bg-[#0b101c] px-2 py-1.5 text-xs text-slate-200"
            />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase text-slate-500">End date</span>
            <input
              type="date"
              value={end}
              onChange={(e) => setEnd(e.target.value)}
              className="mt-0.5 w-full rounded-lg border border-slate-700 bg-[#0b101c] px-2 py-1.5 text-xs text-slate-200"
            />
          </label>
          <div className="flex items-end">
            <Button onClick={run} disabled={loading} className="w-full">
              {loading ? "Running…" : "Run backtest"}
            </Button>
          </div>
        </div>
        <div className="mt-2 flex gap-1 overflow-x-auto">
          {TIMEFRAMES.map((t) => (
            <Chip key={t} active={t === tf} onClick={() => setTf(t)}>
              {t.toUpperCase()}
            </Chip>
          ))}
        </div>
        {settings && (
          <p className="mt-2 text-[10px] text-slate-500">
            Using your saved strategy inputs: poles {settings.poles} · period {settings.period} · mult{" "}
            {settings.multiplier} · StochRSI {settings.stochLength}/{settings.rsiLength}/{settings.stochK}/
            {settings.stochD} · thresholds {settings.rsiUpperThreshold}/{settings.rsiLowerThreshold} · SMA{" "}
            {settings.smaLength} · regime {String(settings.useRegime)} · bullish candle{" "}
            {String(settings.useBullishCandle)} · stop {String(settings.useStopLoss)}. Change them in Settings.
          </p>
        )}
      </Card>

      {error && <ErrorBox message={error} />}
      {loading && <Loading label="Downloading real Binance history and simulating…" />}

      {result && (
        <>
          <Card
            title={`${result.symbol} ${result.timeframe} · ${result.candles} candles (${fmtTime(result.firstCandle)} → ${fmtTime(result.lastCandle)})`}
          >
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
              <Stat label="Total trades" value={result.stats.totalTrades} />
              <Stat label="Wins" value={result.stats.wins} tone="good" />
              <Stat label="Losses" value={result.stats.losses} tone="bad" />
              <Stat label="Win rate" value={`${fmtNum(result.stats.winRate, 1)}%`} />
              <Stat
                label="Net P&L"
                value={fmtPct(result.stats.netPnlPct)}
                tone={result.stats.netPnlPct >= 0 ? "good" : "bad"}
              />
              <Stat label="Max drawdown" value={`${fmtNum(result.stats.maxDrawdownPct, 1)}%`} tone="warn" />
              <Stat
                label="Profit factor"
                value={Number.isFinite(result.stats.profitFactor) ? fmtNum(result.stats.profitFactor) : "∞"}
              />
              <Stat label="Average trade" value={fmtPct(result.stats.avgTradePct)} />
              <Stat label="Largest win" value={fmtPct(result.stats.largestWinPct)} tone="good" />
              <Stat label="Largest loss" value={fmtPct(result.stats.largestLossPct)} tone="bad" />
            </div>
            <div className="mt-3">
              <EquityChart points={result.equityCurve} />
            </div>
            <p className="mt-1 text-[10px] text-slate-500">
              Entries fill on the next bar open after a valid signal (process_orders_on_close=false), 0.1% commission
              per side, stop resting at the lower Gaussian band. Historical results only.
            </p>
          </Card>

          <Card title="Trades">
            <div className="max-h-96 overflow-auto">
              <table className="w-full text-left text-[11px] tabular-nums">
                <thead className="sticky top-0 bg-[#0d1220] text-[10px] uppercase text-slate-500">
                  <tr>
                    <th className="py-1">Entry time</th>
                    <th>Entry</th>
                    <th>Exit time</th>
                    <th>Exit</th>
                    <th>Reason</th>
                    <th>P&L</th>
                  </tr>
                </thead>
                <tbody>
                  {result.trades.map((t, i) => (
                    <tr key={i} className="border-t border-slate-800/60">
                      <td className="py-1 text-slate-400">{fmtTime(t.entryTime)}</td>
                      <td>{fmtPrice(t.entryPrice)}</td>
                      <td className="text-slate-400">{fmtTime(t.exitTime)}</td>
                      <td>{fmtPrice(t.exitPrice)}</td>
                      <td className="text-slate-500">{t.reason}</td>
                      <td className={(t.pnlPct ?? 0) >= 0 ? "text-emerald-400" : "text-rose-400"}>
                        {fmtPct(t.pnlPct)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {!result.trades.length && (
                <p className="p-3 text-xs text-slate-500">
                  The strategy produced no entries in this window — that is the real result, nothing is invented.
                </p>
              )}
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
